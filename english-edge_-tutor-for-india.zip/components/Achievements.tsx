
import React from 'react';
import { Trophy, Flame, Star, Target, Zap, Lock } from 'lucide-react';
import { Achievement } from '../types';

export const Achievements: React.FC = () => {
  const achievements: Achievement[] = [
    { id: '1', title: 'First Steps', description: 'Complete your first practice session', icon: '🎯', unlocked: true },
    { id: '2', title: 'On Fire', description: 'Reach a 3-day streak', icon: '🔥', unlocked: true },
    { id: '3', title: 'Fluency Master', description: 'Score 9/10 in fluency', icon: '⚡', unlocked: false },
    { id: '4', title: 'Vocab Hero', description: 'Learn 50 new words', icon: '📚', unlocked: false },
    { id: '5', title: 'Consistency King', description: 'Practice for 7 days in a row', icon: '👑', unlocked: false },
    { id: '6', title: 'Perfect Pronunciation', description: 'Get 100% pronunciation score', icon: '🎤', unlocked: false },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl p-8 text-white shadow-glow flex items-center justify-between overflow-hidden relative">
         <div className="absolute top-0 right-0 p-8 opacity-20"><Trophy size={140} /></div>
         <div className="relative z-10">
            <h1 className="text-3xl font-heading font-bold mb-2">Your Trophies</h1>
            <p className="font-medium opacity-90">Keep practicing to unlock more badges!</p>
         </div>
         <div className="relative z-10 hidden sm:block text-right">
            <div className="text-4xl font-heading font-bold">2/6</div>
            <div className="text-xs font-bold uppercase tracking-widest opacity-80">Unlocked</div>
         </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
         {achievements.map((badge) => (
           <div 
             key={badge.id} 
             className={`
               relative p-6 rounded-2xl border text-center flex flex-col items-center gap-4 transition-all duration-300
               ${badge.unlocked 
                 ? 'bg-surface-light dark:bg-surface-dark border-primary-200 dark:border-primary-900 shadow-soft hover:-translate-y-1' 
                 : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800 opacity-70 grayscale'}
             `}
           >
              <div className={`
                 w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-sm
                 ${badge.unlocked ? 'bg-white dark:bg-slate-800' : 'bg-slate-200 dark:bg-slate-800'}
              `}>
                 {badge.icon}
              </div>
              <div>
                 <h3 className={`font-bold mb-1 ${badge.unlocked ? 'text-slate-800 dark:text-white' : 'text-slate-500'}`}>{badge.title}</h3>
                 <p className="text-xs text-slate-500 dark:text-slate-400">{badge.description}</p>
              </div>
              {!badge.unlocked && (
                 <div className="absolute top-3 right-3 text-slate-400"><Lock size={14} /></div>
              )}
           </div>
         ))}
      </div>
    </div>
  );
};
