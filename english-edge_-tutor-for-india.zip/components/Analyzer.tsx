
import React, { useState } from 'react';
import { Send, Activity, Ear, Volume2, Heart, Smile, BookOpen, ChevronUp, ChevronDown, Sparkles, Lightbulb, Play, AlertCircle, CheckCircle2, Languages, BarChart, Mic } from 'lucide-react';
import { analyzeSentence, analyzeAudio } from '../services/geminiService';
import { AnalysisResult, ProgressRecord } from '../types';
import { VoiceInput } from './VoiceInput';

export const Analyzer: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [showHindi, setShowHindi] = useState(true);

  // Function to save result to history
  const saveToHistory = (data: AnalysisResult, type: 'speaking' | 'text') => {
    const record: ProgressRecord = {
      id: Date.now().toString(),
      date: Date.now(),
      type: type,
      overallScore: data.score,
      pronunciationScore: data.pronunciation?.score || 0,
      grammarScore: data.score * 10,
      fluencyScore: data.fluencyMetrics?.score || 0,
      vocabScore: data.vocabularyAnalysis?.varietyScore || 0
    };

    const existing = localStorage.getItem('user_progress_history');
    let history: ProgressRecord[] = [];
    if (existing) history = JSON.parse(existing);
    history.push(record);
    localStorage.setItem('user_progress_history', JSON.stringify(history));
  };

  const handleAudioCaptured = async (base64: string, mimeType: string) => {
    setLoading(true);
    setResult(null);
    try {
      const data = await analyzeAudio(base64, mimeType);
      setResult(data);
      saveToHistory(data, 'speaking');
      if (data.transcript) setInputText(data.transcript);
    } catch (error) {
      alert("Failed to analyze audio.");
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeText = async () => {
    if (!inputText.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const data = await analyzeSentence(inputText);
      setResult(data);
      saveToHistory(data, 'text');
    } catch (error) {
      alert("Failed to analyze. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const playCorrection = (text: string, rate: number = 1.0) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  };

  const getScoreColor = (score: number, max: number = 10) => {
    const percentage = (score / max) * 100;
    if (percentage >= 80) return 'text-teal-600 border-teal-500 shadow-teal-500/20';
    if (percentage >= 50) return 'text-primary-500 border-primary-500 shadow-primary-500/20';
    return 'text-indigo-400 border-indigo-400 shadow-indigo-500/20';
  };

  const QUICK_PROMPTS = [
    "Introduce yourself professionally",
    "Describe your daily routine",
    "Talk about your favorite movie",
    "Explain why you want to learn English",
    "Describe your hometown"
  ];

  return (
    <div className="space-y-6 md:space-y-8 max-w-5xl mx-auto h-full flex flex-col pb-4">
      {/* Header with Photo */}
      <div className="relative rounded-3xl overflow-hidden shadow-soft h-40 md:h-56 lg:h-64 group shrink-0">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-950/90 via-purple-900/80 to-transparent z-10 mix-blend-multiply"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/80 to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1559739433-286aecc5a9a7?q=80&w=1000&auto=format&fit=crop" 
          alt="Studio Microphone" 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute bottom-0 left-0 p-6 md:p-10 z-20 text-white">
           <div className="flex items-center gap-2 text-indigo-200 font-bold uppercase text-[10px] md:text-xs tracking-widest mb-2">
             <Activity size={14} className="text-indigo-400" />
             AI Language Lab
           </div>
           <h2 className="text-2xl md:text-4xl lg:text-5xl font-heading font-bold leading-tight">Master Your<br/>Pronunciation</h2>
        </div>
      </div>

      {/* Input Area */}
      <div className="space-y-4">
        <div className="relative group">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Start speaking or typing to analyze..."
            className="w-full h-40 md:h-56 p-6 rounded-2xl bg-surface-light dark:bg-surface-dark border-2 border-transparent focus:border-primary-500 dark:focus:border-primary-500 outline-none resize-none shadow-soft text-base md:text-lg font-medium transition-all relative z-10 text-text-main dark:text-white placeholder-slate-400"
          />
          <div className="absolute top-4 right-4 z-20 hidden md:block">
            <div className="flex items-center gap-2 text-xs font-bold text-primary-500 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30 px-3 py-1.5 rounded-full">
                <Heart size={12} className="fill-current" />
                <span>I'm here to help you learn</span>
            </div>
          </div>
          <div className="absolute bottom-4 right-4 md:bottom-5 md:right-5 flex gap-3 relative z-20 items-center">
            <VoiceInput onAudioCaptured={handleAudioCaptured} />
            <button
              onClick={handleAnalyzeText}
              disabled={!inputText.trim() || loading}
              className="px-6 md:px-8 py-3 bg-gradient-to-r from-primary-DEFAULT to-primary-dark text-white rounded-full font-heading font-bold hover:shadow-glow disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-all active:scale-95 text-sm md:text-base"
            >
              {loading ? 'Processing...' : <>Analyze <Send size={18} /></>}
            </button>
          </div>
        </div>

        {/* Quick Prompts */}
        {!inputText && !loading && !result && (
          <div className="animate-in fade-in slide-in-from-top-2">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Need inspiration?</p>
            <div className="flex flex-wrap gap-2">
              {QUICK_PROMPTS.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => setInputText(prompt)}
                  className="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-sm font-medium text-slate-600 dark:text-slate-300 hover:border-primary-400 hover:text-primary-600 dark:hover:text-primary-400 transition-all shadow-sm active:scale-95"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {!result && !loading && (
        <div className="text-center p-4">
           <p className="text-slate-400 dark:text-slate-500 text-sm font-medium flex items-center justify-center gap-2">
             <Heart size={14} className="text-primary-400" />
             Mistakes are normal — that's how we grow. Keep going!
           </p>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
          
          <div className="grid gap-6 lg:grid-cols-3">
             {/* 1. Assessment Engine */}
             <div className="lg:col-span-2 bg-surface-light dark:bg-surface-dark p-6 md:p-8 rounded-2xl shadow-soft border border-white dark:border-slate-800 flex items-center justify-between">
                <div className="flex-1 pr-4">
                   <div className="flex items-center gap-2 mb-1">
                       <h3 className="text-slate-400 dark:text-slate-500 text-[10px] md:text-xs font-bold uppercase tracking-widest">Assessment</h3>
                       {result.cefrLevel && <span className="bg-primary-100 text-primary-700 px-2 py-0.5 rounded text-[10px] font-bold">{result.cefrLevel} Level</span>}
                   </div>
                   <p className="text-xl md:text-2xl font-heading font-bold text-text-main dark:text-white leading-tight">"{result.encouragement}"</p>
                </div>
                <div className={`relative w-20 h-20 md:w-24 md:h-24 flex items-center justify-center rounded-full border-[6px] text-2xl md:text-3xl font-heading font-bold shadow-xl ${getScoreColor(result.score, 10)} bg-white dark:bg-slate-900 shrink-0`}>
                  {result.score}
                </div>
             </div>

             {/* 2. Your Strengths */}
             <div className="bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl p-6 md:p-8 shadow-glow text-white relative overflow-hidden flex flex-col justify-center">
                <div className="flex items-center gap-3 font-heading font-bold text-lg md:text-xl mb-4 relative z-10">
                   <Sparkles size={24} className="text-yellow-300 fill-yellow-300" />
                   <h3>Your Strengths</h3>
                </div>
                <div className="flex flex-wrap gap-2 relative z-10">
                  {result.strengths.map((strength, i) => (
                    <div key={i} className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1.5 md:px-4 md:py-2 rounded-xl">
                      <CheckCircle2 size={16} className="text-white" />
                      <span className="font-medium text-xs md:text-sm">{strength}</span>
                    </div>
                  ))}
                </div>
             </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
             {/* 3. Pronunciation Engine */}
             {result.pronunciation && (
                <div className="bg-gradient-to-br from-[#5B6DFF] to-[#7A88FF] text-white rounded-2xl p-6 md:p-8 shadow-glow overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                  
                  <div className="flex items-center justify-between mb-8 relative z-10">
                    <div className="flex items-center gap-3 font-heading font-bold text-xl md:text-2xl">
                      <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-md"><Ear size={24} /></div>
                      <h3>Pronunciation</h3>
                    </div>
                    <div className="flex flex-col items-end">
                       <div className="text-3xl md:text-4xl font-heading font-bold">{result.pronunciation.score}%</div>
                       <div className="text-[10px] opacity-80 uppercase tracking-widest font-bold">Accuracy</div>
                    </div>
                  </div>

                  {result.pronunciation.mispronouncedWords.length > 0 ? (
                    <div className="space-y-3">
                      <p className="text-xs uppercase tracking-widest opacity-90 font-bold flex items-center gap-2 mb-2">
                        <AlertCircle size={16} /> Practice Words & Tips
                      </p>
                      
                      {result.pronunciation.mispronouncedWords.map((item, idx) => (
                        <div key={idx} className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 rounded-xl p-4 shadow-sm border border-slate-100 dark:border-slate-800">
                          <div className="flex justify-between items-start mb-3">
                             <div>
                                <span className="font-heading font-bold text-primary-600 dark:text-primary-400 text-lg">{item.word}</span>
                                <span className="block text-xs font-mono text-slate-500">/{item.ipa}/</span>
                             </div>
                             <button onClick={() => playCorrection(item.word)} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-full"><Volume2 size={16} /></button>
                          </div>
                          
                          <div className="space-y-2 text-sm">
                              {item.syllables && (
                                <div className="flex gap-2"><span className="font-bold text-xs uppercase text-slate-400 w-16">Breakdown</span> {item.syllables}</div>
                              )}
                              <div className="flex gap-2"><span className="font-bold text-xs uppercase text-slate-400 w-16">Tip</span> {item.correctiveTip}</div>
                              {item.mouthPosition && (
                                <div className="flex gap-2 bg-slate-50 dark:bg-slate-800 p-2 rounded"><span className="text-lg">👄</span> {item.mouthPosition}</div>
                              )}
                              {showHindi && item.hindiTip && (
                                 <div className="flex gap-2 text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 p-2 rounded"><span className="text-lg">🇮🇳</span> {item.hindiTip}</div>
                              )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-white/20 p-4 rounded-xl backdrop-blur-sm flex items-center gap-2"><CheckCircle2/> Excellent pronunciation!</div>
                  )}
                </div>
             )}

             {/* 4. Learning Insights */}
             <div className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 p-6 md:p-8 flex flex-col">
                  <div className="flex items-center gap-3 font-heading font-bold text-lg mb-6 text-slate-800 dark:text-white">
                     <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-500"><Lightbulb size={20} /></div>
                     <h3>Learning Insights</h3>
                  </div>
                  {result.learningInsights && result.learningInsights.length > 0 ? (
                     <div className="space-y-4 flex-1">
                       {result.learningInsights.map((insight, idx) => (
                         <div key={idx} className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-xl border-l-4 border-indigo-400">
                            <span className="text-[10px] uppercase font-bold text-indigo-500 dark:text-indigo-400 block mb-1">{insight.type}</span>
                            <p className="font-medium text-slate-800 dark:text-slate-200 mb-2">{insight.observation}</p>
                            <div className="bg-white dark:bg-slate-800 p-2 rounded border border-indigo-100 dark:border-indigo-900/50">
                               <span className="text-[10px] text-slate-400 uppercase font-bold">Try</span> <span className="font-bold text-indigo-600 dark:text-indigo-400">{insight.softCorrection}</span>
                            </div>
                         </div>
                       ))}
                     </div>
                  ) : (
                    <div className="text-slate-500">No specific improvements needed. Great job!</div>
                  )}
              </div>
          </div>

          {/* 5. Vocabulary & Fluency Engines */}
          <div className="grid gap-6 sm:grid-cols-2">
            {/* Vocab Engine */}
            <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800">
              <div className="flex items-center gap-2 text-indigo-500 font-bold mb-4 uppercase text-xs tracking-widest">
                <BookOpen size={16} />
                <h4>Vocabulary Engine</h4>
              </div>
              
              {result.vocabularyAnalysis ? (
                 <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm">
                       <span className="text-slate-500 dark:text-slate-400">Level Detected</span>
                       <span className="font-bold text-indigo-600 dark:text-indigo-400">{result.vocabularyAnalysis.cefrLevel}</span>
                    </div>
                    <div>
                        <span className="text-xs text-slate-400 font-bold uppercase">Better Words</span>
                        <div className="flex flex-wrap gap-2 mt-2">
                            {result.vocabularyAnalysis.betterWords.map((w, i) => (
                                <span key={i} className="px-2 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded text-xs font-bold">{w}</span>
                            ))}
                        </div>
                    </div>
                 </div>
              ) : (
                <p className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{result.betterVocabulary}</p>
              )}
            </div>

            {/* Fluency Engine */}
            <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800">
              <div className="flex items-center gap-2 text-primary-500 font-bold mb-4 uppercase text-xs tracking-widest">
                <BarChart size={16} />
                <h4>Fluency Engine</h4>
              </div>
              
              {result.fluencyMetrics ? (
                 <div className="grid grid-cols-2 gap-2">
                    <div className="bg-primary-50 dark:bg-primary-900/20 p-3 rounded-xl text-center">
                       <div className="text-xl font-bold text-primary-600 dark:text-primary-400">{result.fluencyMetrics.wpm}</div>
                       <div className="text-[10px] text-slate-400 uppercase">WPM</div>
                    </div>
                    <div className="bg-primary-50 dark:bg-primary-900/20 p-3 rounded-xl text-center">
                       <div className="text-xl font-bold text-primary-600 dark:text-primary-400">{result.fluencyMetrics.fillersCount}</div>
                       <div className="text-[10px] text-slate-400 uppercase">Fillers</div>
                    </div>
                 </div>
              ) : (
                <p className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{result.fluencyFeedback}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
