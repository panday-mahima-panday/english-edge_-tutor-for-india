
import React, { useState, useEffect, useRef } from 'react';
import { Send, User, Bot, Sparkles, Loader2, Heart, MessageSquare } from 'lucide-react';
import { createChatSession } from '../services/geminiService';
import { ChatMessage } from '../types';
import { Chat, GenerateContentResponse } from "@google/genai";
import { VoiceInput } from './VoiceInput';

const TOPICS = [
  "Self Intro",
  "Job Interview",
  "College Life",
  "Internships",
  "Exams & Viva",
  "Hostel Life",
  "Ordering Food",
  "Travel in India",
  "Movies & Cricket"
];

const STARTERS = [
  "Can you help me introduce myself professionally?",
  "Let's roleplay a job interview.",
  "How do I ask for directions in a new city?",
  "I want to practice ordering food at a restaurant."
];

export const Conversation: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeTopic, setActiveTopic] = useState<string | null>(null);
  
  const chatSessionRef = useRef<Chat | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatSessionRef.current = createChatSession();
    setMessages([
      {
        id: 'init',
        role: 'model',
        text: "Hello! I'm your friendly English coach. This is a safe space to practice without judgement. Choose a topic or just say hi!",
        timestamp: Date.now()
      }
    ]);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || !chatSessionRef.current) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const result: GenerateContentResponse = await chatSessionRef.current.sendMessage({ message: text });
      const responseText = result.text;

      if (responseText) {
        const botMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          text: responseText,
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, botMsg]);
        
        const utterance = new SpeechSynthesisUtterance(responseText);
        utterance.lang = 'en-US';
        utterance.rate = 0.9;
        window.speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error("Chat error:", error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleVoiceInput = (base64: string) => {
    // In a real implementation, we would send the audio to Gemini's multimodal chat.
    // For now, let's assume transcription happens elsewhere or we send a placeholder "Audio message"
    alert("Voice messaging active! (Simulated transcription: 'Hello coach!')");
    handleSend("Hello coach! (Voice Message)");
  };

  const startTopic = (topic: string) => {
    setActiveTopic(topic);
    const prompt = `Let's talk about ${topic}. Please start the conversation as a roleplay.`;
    handleSend(prompt);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] md:h-[calc(100vh-6rem)] max-w-5xl mx-auto bg-surface-light dark:bg-surface-dark shadow-soft dark:shadow-[0_0_40px_-10px_rgba(0,0,0,0.3)] md:rounded-2xl overflow-hidden border border-white dark:border-slate-800">
      
      {/* Header with Photo */}
      <div className="relative h-20 md:h-28 shrink-0 overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/90 via-primary-800/80 to-transparent z-10 mix-blend-multiply"></div>
        <img 
          src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1000&auto=format&fit=crop" 
          alt="Clean Conversation Workspace" 
          className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 grayscale-[20%]"
        />
        <div className="absolute bottom-0 left-0 p-4 md:p-5 z-20 flex items-center gap-4">
           <div className="relative">
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5 md:h-3 md:w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 md:h-3 md:w-3 bg-green-500"></span>
              </span>
              <div className="bg-white/20 p-1.5 md:p-2 rounded-full backdrop-blur-sm shadow-sm">
                <Bot className="w-5 h-5 md:w-6 md:h-6 text-white" />
              </div>
           </div>
           <div>
               <h2 className="text-white font-heading font-bold text-lg md:text-xl leading-none mb-1">Conversation Coach</h2>
               <p className="text-indigo-100 text-[10px] md:text-xs font-medium tracking-wide flex items-center gap-1 opacity-90">
                 <Heart size={10} className="fill-current" /> Safe Space • Roleplay Mode
               </p>
           </div>
        </div>
      </div>

      {/* Topics Header */}
      <div className="p-3 md:p-4 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800 overflow-x-auto no-scrollbar whitespace-nowrap shrink-0">
        <div className="flex gap-2">
          {/* Quick Starters Label */}
          <div className="flex items-center gap-2 mr-2">
            <div className="p-1.5 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-lg">
              <Sparkles size={14} />
            </div>
          </div>
          
          {TOPICS.map(topic => (
            <button
              key={topic}
              onClick={() => startTopic(topic)}
              className={`px-4 py-1.5 md:px-5 md:py-2 rounded-full text-[10px] md:text-xs font-bold transition-all duration-300 ${
                activeTopic === topic
                  ? 'bg-primary-600 text-white shadow-glow'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-primary-50 dark:hover:bg-slate-700 hover:border-primary-200'
              }`}
            >
              {topic}
            </button>
          ))}
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-white/30 dark:bg-slate-900/20">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex w-full animate-in fade-in slide-in-from-bottom-2 duration-300 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex max-w-[85%] sm:max-w-[75%] gap-2 md:gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-7 h-7 md:w-8 md:h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
                msg.role === 'user' ? 'bg-primary-100 dark:bg-primary-900' : 'bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700'
              }`}>
                {msg.role === 'user' ? <User className="w-3.5 h-3.5 md:w-4 md:h-4 text-primary-600 dark:text-primary-400" /> : <Bot className="w-3.5 h-3.5 md:w-4 md:h-4 text-primary-600 dark:text-primary-400" />}
              </div>
              
              <div className="flex flex-col gap-1">
                <div className={`p-3 md:p-3.5 rounded-2xl shadow-sm text-sm sm:text-base font-medium leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-br from-primary-DEFAULT to-primary-600 text-white rounded-tr-none'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-tl-none border border-slate-100 dark:border-slate-700'
                }`}>
                  {msg.text}
                </div>
                <span className={`text-[10px] text-slate-400 font-medium ${msg.role === 'user' ? 'text-right mr-1' : 'text-left ml-1'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
           <div className="flex w-full justify-start animate-pulse">
            <div className="flex gap-2 items-center bg-white dark:bg-slate-800 p-3 px-4 rounded-2xl rounded-tl-none border border-slate-100 dark:border-slate-700 ml-10 md:ml-11 shadow-sm">
               <Loader2 className="w-3 h-3 md:w-3.5 md:h-3.5 animate-spin text-primary-500" />
               <span className="text-[10px] md:text-xs font-bold text-slate-400">Coach is typing...</span>
            </div>
           </div>
        )}
        <div ref={bottomRef} />
        
        {messages.length <= 1 && (
           <div className="mt-4 flex flex-col items-center gap-3">
             <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Or try a quick start</p>
             <div className="flex flex-wrap gap-2 justify-center">
               {STARTERS.map((text, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSend(text)}
                    className="bg-white dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 px-4 py-2 rounded-full text-xs font-bold text-slate-600 dark:text-slate-400 hover:border-primary-300 hover:text-primary-600 transition flex items-center gap-2 shadow-sm hover:shadow-md"
                  >
                     <MessageSquare size={12} className="text-primary-400" /> {text}
                  </button>
               ))}
             </div>
           </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-3 md:p-4 bg-white dark:bg-surface-dark border-t border-slate-100 dark:border-slate-800 shrink-0">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          className="flex items-center gap-2 bg-slate-50 dark:bg-slate-900/50 p-1.5 md:p-2 rounded-full border border-slate-200 dark:border-slate-700 focus-within:border-primary-400 dark:focus-within:border-primary-500 transition-colors shadow-inner"
        >
          <VoiceInput onAudioCaptured={(base64) => handleVoiceInput(base64)} className="shrink-0" buttonClass="w-10 h-10" iconSize={18} />
          
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 bg-transparent outline-none text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-sm md:text-base font-medium px-2 min-w-0"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isTyping}
            className="p-2.5 md:p-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-full hover:shadow-glow disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 shrink-0"
          >
            <Send className="w-4 h-4 md:w-[18px] md:h-[18px]" />
          </button>
        </form>
      </div>
    </div>
  );
};
