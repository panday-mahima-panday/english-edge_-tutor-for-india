
import React, { useEffect, useState } from 'react';
import { BookOpen, Mic, Lightbulb, Volume2, Loader2, RefreshCw, CheckCircle, HelpCircle, Star, Trophy, Sparkles, Heart, Map, Lock, PlayCircle, CheckCircle2, Smile, XCircle, ArrowRight, Flame } from 'lucide-react';
import { getDailyPractice } from '../services/geminiService';
import { DailyPracticeContent, QuizItem, PathLevel } from '../types';
import { VoiceInput } from './VoiceInput';

export const DailyPractice: React.FC = () => {
  const [content, setContent] = useState<DailyPracticeContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [completedTasks, setCompletedTasks] = useState<{ [key: string]: boolean }>({});
  
  // Quiz states
  const [grammarQuizAnswer, setGrammarQuizAnswer] = useState<number | null>(null);
  const [vocabQuizAnswer, setVocabQuizAnswer] = useState<number | null>(null);

  const todayKey = `daily_progress_${new Date().toDateString()}`;
  const streak = 3; // Mocked streak for UI enhancement

  // Hardcoded Learning Path Data
  const learningPath: PathLevel[] = [
    {
      id: 'beginner',
      name: 'Beginner',
      description: 'Foundations of daily speech',
      status: 'completed',
      tasks: [
        { title: 'Master Basic Greetings', description: 'Learn 10 common ways to say hello', duration: '5 min' },
        { title: 'Present Simple Tense', description: 'Talk about your daily routine', duration: '10 min' },
      ]
    },
    {
      id: 'intermediate',
      name: 'Intermediate',
      description: 'Conversations & Storytelling',
      status: 'active',
      tasks: [
        { title: 'Past Tense Practice', description: 'Narrate a past event clearly', duration: '15 min' },
        { title: 'Travel Vocabulary', description: 'Booking hotels and asking directions', duration: '10 min' },
        { title: 'Expressing Opinions', description: 'Agreeing and disagreeing politely', duration: '12 min' },
      ]
    },
    {
      id: 'advanced',
      name: 'Advanced',
      description: 'Professional & Complex Topics',
      status: 'locked',
      tasks: [
        { title: 'Job Interview Prep', description: 'Answering behavioral questions', duration: '20 min' },
        { title: 'Complex Clauses', description: 'Using although, despite, whereas', duration: '15 min' },
      ]
    },
    {
      id: 'mastery',
      name: 'Mastery',
      description: 'Native-level Nuance & Style',
      status: 'locked',
      tasks: [
        { title: 'Idioms & Phrasal Verbs', description: 'Sounding like a local', duration: '20 min' },
        { title: 'Accent Refinement', description: 'Intonation and stress patterns', duration: '25 min' },
      ]
    }
  ];

  const fetchContent = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getDailyPractice();
      setContent(data);
      
      const savedProgress = localStorage.getItem(todayKey);
      if (savedProgress) {
        setCompletedTasks(JSON.parse(savedProgress));
      } else {
        setCompletedTasks({});
      }
    } catch (err) {
      setError("Failed to load daily practice. Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContent();
  }, []);

  useEffect(() => {
    if (!content) return;
    const totalTasks = 3; 
    const completedCount = 
      (completedTasks['speaking'] ? 1 : 0) + 
      (completedTasks['grammarQuiz'] ? 1 : 0) + 
      (completedTasks['vocabQuiz'] ? 1 : 0);
    
    setProgress((completedCount / totalTasks) * 100);
    localStorage.setItem(todayKey, JSON.stringify(completedTasks));
  }, [completedTasks, content]);

  const markTaskComplete = (taskKey: string) => {
    setCompletedTasks(prev => ({ ...prev, [taskKey]: true }));
  };

  const handleQuizAnswer = (type: 'grammar' | 'vocab', answerIdx: number, correctIdx: number) => {
    if (type === 'grammar') {
      setGrammarQuizAnswer(answerIdx);
      if (answerIdx === correctIdx) markTaskComplete('grammarQuiz');
    } else {
      setVocabQuizAnswer(answerIdx);
      if (answerIdx === correctIdx) markTaskComplete('vocabQuiz');
    }
  };

  const speak = (text: string, rate = 1) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  };

  // Dummy handler for speaking task voice input
  const handleSpeakingTaskAudio = (base64: string) => {
    // In a real app, analyze this audio. For now, just mark complete.
    markTaskComplete('speaking');
    alert("Great job! Response recorded.");
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center text-slate-500 dark:text-slate-400">
        <Loader2 className="w-12 h-12 animate-spin mb-4 text-primary-DEFAULT" />
        <p className="font-heading font-medium text-lg">Preparing your customized lesson...</p>
      </div>
    );
  }

  if (error || !content) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center px-4">
        <p className="text-indigo-500 mb-6 font-medium bg-indigo-50 dark:bg-indigo-900/20 px-6 py-3 rounded-xl border border-indigo-100 dark:border-indigo-800 text-sm md:text-base">{error || "Something went wrong."}</p>
        <button 
          onClick={fetchContent}
          className="px-8 py-3 bg-gradient-to-r from-primary-DEFAULT to-primary-dark text-white rounded-full flex items-center gap-2 hover:shadow-glow transition-all duration-300 font-bold text-sm md:text-base"
        >
          <RefreshCw size={18} /> Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-10 max-w-5xl mx-auto pb-4">
      {/* Immersive Header */}
      <div className="relative rounded-3xl overflow-hidden shadow-soft group h-56 md:h-72 lg:h-80 transition-all">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/80 via-primary-900/40 to-indigo-900/20 z-10 mix-blend-multiply"></div>
        <img 
          src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?q=80&w=1000&auto=format&fit=crop" 
          alt="Clean workspace with laptop" 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute top-6 right-6 z-20">
           <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/20 text-white shadow-lg">
              <Flame size={18} className="text-orange-400 fill-orange-400 animate-pulse" />
              <span className="font-bold text-sm">{streak} Day Streak</span>
           </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 z-20 text-white">
          <div className="flex justify-between items-end">
            <div className="max-w-[70%]">
              <p className="text-indigo-200 font-bold uppercase tracking-wider text-[10px] md:text-xs mb-2 md:mb-3 flex items-center gap-2">
                <Sparkles size={14} className="text-indigo-300" />
                Daily Insight
              </p>
              <h2 className="text-2xl md:text-4xl lg:text-5xl font-heading font-bold leading-tight mb-2 md:mb-3">Consistency is<br className="hidden md:block"/> the Key to Mastery</h2>
              <p className="text-xs md:text-sm text-indigo-100 font-medium flex items-center gap-1.5 opacity-90"><Heart size={12} className="fill-current"/> You're doing great today!</p>
            </div>
            <div className="flex flex-col items-end shrink-0">
                <div className="text-3xl md:text-5xl font-heading font-bold">{Math.round(progress)}%</div>
                <div className="text-[10px] md:text-xs uppercase font-bold text-indigo-200 tracking-wider">Completed</div>
            </div>
          </div>
          <div className="w-full bg-white/20 h-1.5 md:h-2 rounded-full mt-4 md:mt-6 overflow-hidden backdrop-blur-sm">
             <div className="bg-gradient-to-r from-indigo-400 to-purple-400 h-full rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* 1. Daily Speaking Task */}
        <section className="lg:col-span-2 bg-surface-light dark:bg-surface-dark rounded-2xl p-6 md:p-8 shadow-soft border border-white dark:border-slate-800 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-50/50 to-transparent dark:from-indigo-900/10 pointer-events-none"></div>
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-indigo-100 dark:bg-indigo-900/20 rounded-full blur-3xl"></div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 md:mb-6 relative z-10 gap-4">
                <div className="flex items-center gap-3 text-primary-600 dark:text-primary-dark font-heading font-bold text-lg md:text-xl">
                    <div className="p-3 bg-white dark:bg-slate-800 rounded-xl shadow-sm ring-1 ring-indigo-100 dark:ring-slate-700 text-indigo-500"><Mic size={24} /></div>
                    <h3>Speaking Task</h3>
                </div>
                {completedTasks['speaking'] ? (
                    <span className="self-start sm:self-auto text-teal-600 dark:text-teal-400 flex items-center gap-1.5 text-sm font-bold bg-teal-50 dark:bg-teal-900/20 px-4 py-2 rounded-full border border-teal-100 dark:border-teal-900/30"><CheckCircle size={16}/> Completed</span>
                ) : (
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-slate-400 uppercase hidden sm:inline-block">Tap to Record</span>
                      <VoiceInput onAudioCaptured={handleSpeakingTaskAudio} />
                    </div>
                )}
            </div>
            
            <div className="relative z-10 bg-white/60 dark:bg-slate-900/40 backdrop-blur-sm p-6 rounded-2xl border border-indigo-50 dark:border-slate-700/50 mb-4">
              <div className="flex gap-4">
                 <div className="hidden md:block w-1 bg-gradient-to-b from-indigo-400 to-indigo-200 rounded-full"></div>
                 <div>
                    <h4 className="text-xs font-bold uppercase text-slate-400 mb-2 tracking-wider">Today's Prompt</h4>
                    <p className="text-xl md:text-2xl font-medium leading-relaxed text-text-main dark:text-text-inverted">"{content.speakingTask}"</p>
                 </div>
              </div>
            </div>
            
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium flex items-center gap-2 relative z-10 pl-2">
                <div className="w-6 h-6 rounded-full bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-500"><Lightbulb size={12}/></div>
                Tip: Read aloud or answer this question naturally to practice your flow.
            </p>
        </section>

        {/* 2. Vocabulary Section */}
        <section className="space-y-4">
            <div className="flex items-center gap-2 text-primary-600 dark:text-primary-dark font-bold uppercase text-xs tracking-widest pl-1">
            <BookOpen size={16} />
            <h3>Vocabulary of the Day</h3>
            </div>
            
            <div className="grid gap-4">
            {content.vocabulary.map((vocab, index) => (
                <div key={index} className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 hover:shadow-lg transition-all duration-300 group">
                <div className="flex justify-between items-start mb-3">
                    <div className="flex flex-col items-start gap-2">
                    <div className="flex items-center gap-3 flex-wrap">
                        <h4 className="text-xl font-heading font-bold text-text-main dark:text-white group-hover:text-primary-500 transition-colors">{vocab.word}</h4>
                        {vocab.level && <span className="text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-1.5 py-0.5 rounded border border-slate-300 dark:border-slate-600">{vocab.level}</span>}
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded inline-block">/{vocab.pronunciationGuide}/</span>
                    </div>
                    <button 
                    onClick={() => speak(vocab.word)}
                    className="p-3 bg-white dark:bg-slate-800 text-primary-500 dark:text-primary-dark rounded-full shadow-sm hover:scale-110 active:scale-95 transition-all shrink-0"
                    >
                    <Volume2 size={20} />
                    </button>
                </div>
                <p className="text-slate-600 dark:text-slate-300 font-medium mb-3">"{vocab.meaning}"</p>
                <div className="text-sm text-slate-500 dark:text-slate-400 border-l-2 border-primary-200 dark:border-primary-800 pl-3 italic leading-relaxed">
                    {vocab.example}
                </div>
                {/* Rich Context */}
                {vocab.synonyms && vocab.synonyms.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {vocab.synonyms.map(syn => (
                      <span key={syn} className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 px-2 py-1 rounded">{syn}</span>
                    ))}
                  </div>
                )}
                </div>
            ))}
            </div>
        </section>

        <div className="space-y-6">
            <QuizSection 
                title="Vocabulary Quiz"
                icon={<HelpCircle size={20} />}
                quiz={content.vocabQuiz}
                selectedAnswer={vocabQuizAnswer}
                onAnswer={(idx) => handleQuizAnswer('vocab', idx, content.vocabQuiz.correctAnswer)}
            />

            <section className="bg-indigo-50/80 dark:bg-slate-800/80 border-l-4 border-indigo-400 p-6 rounded-r-2xl shadow-sm backdrop-blur-sm">
                <div className="flex items-center gap-3 text-indigo-600 dark:text-indigo-400 font-heading font-bold mb-3">
                <Lightbulb size={22} className="fill-indigo-100 dark:fill-indigo-900/30" />
                <h3>Grammar Tip</h3>
                </div>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-medium">{content.grammarTip}</p>
            </section>

            <QuizSection 
                title="Grammar Challenge"
                icon={<Trophy size={20} />}
                quiz={content.grammarChallenge}
                selectedAnswer={grammarQuizAnswer}
                onAnswer={(idx) => handleQuizAnswer('grammar', idx, content.grammarChallenge.correctAnswer)}
            />
        </div>
      </div>
    </div>
  );
};

const QuizSection: React.FC<{
    title: string;
    icon: React.ReactNode;
    quiz: QuizItem;
    selectedAnswer: number | null;
    onAnswer: (idx: number) => void;
}> = ({ title, icon, quiz, selectedAnswer, onAnswer }) => {
    const isAnswered = selectedAnswer !== null;
    const isCorrect = selectedAnswer === quiz.correctAnswer;

    return (
        <section className="bg-surface-light dark:bg-surface-dark rounded-2xl p-6 shadow-soft border border-white dark:border-slate-800 h-full flex flex-col">
            <div className="flex items-center gap-3 text-text-main dark:text-white font-heading font-bold mb-5">
                <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-primary-500 dark:text-primary-dark">{icon}</div>
                <h3>{title}</h3>
            </div>
            
            <p className="text-slate-700 dark:text-slate-300 font-medium text-lg mb-6 leading-relaxed flex-1">{quiz.question}</p>
            
            <div className="space-y-3">
                {quiz.options.map((option, idx) => {
                    let btnClass = "w-full text-left p-4 rounded-xl border text-sm md:text-base font-medium transition-all duration-200 ";
                    
                    if (isAnswered) {
                        if (idx === quiz.correctAnswer) {
                            btnClass += "bg-teal-50 border-teal-500 text-teal-800 dark:bg-teal-900/30 dark:text-teal-200 dark:border-teal-600 shadow-sm";
                        } else if (idx === selectedAnswer) {
                            btnClass += "bg-indigo-50 border-indigo-400 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-200 dark:border-indigo-600";
                        } else {
                            btnClass += "bg-slate-50 border-slate-100 text-slate-400 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-600 opacity-50";
                        }
                    } else {
                        btnClass += "bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:border-primary-300 dark:hover:border-primary-700 active:scale-[0.99]";
                    }

                    return (
                        <button 
                            key={idx}
                            disabled={isAnswered}
                            onClick={() => onAnswer(idx)}
                            className={btnClass}
                        >
                            {option}
                        </button>
                    );
                })}
            </div>

            {isAnswered && (
                <div className={`mt-5 p-4 rounded-xl text-sm animate-in fade-in slide-in-from-top-2 ${isCorrect ? 'bg-teal-50 text-teal-800 dark:bg-teal-900/20 dark:text-teal-200' : 'bg-indigo-50 text-indigo-800 dark:bg-indigo-900/20 dark:text-indigo-200'}`}>
                    <div className="flex items-center gap-2 font-bold mb-1">
                        {isCorrect ? <CheckCircle2 size={16}/> : <Sparkles size={16}/>}
                        <span>{isCorrect ? 'Correct!' : 'Keep trying, you can do this!'}</span>
                    </div>
                    <p className="opacity-90 leading-relaxed">{quiz.explanation}</p>
                </div>
            )}
        </section>
    );
};
