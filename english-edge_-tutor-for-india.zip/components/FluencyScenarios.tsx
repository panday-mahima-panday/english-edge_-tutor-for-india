
import React, { useState } from 'react';
import { PlayCircle, Mic, Coffee, Briefcase, GraduationCap, Map, User, CheckCircle2, ArrowRight } from 'lucide-react';
import { FluencyScenario, AnalysisResult } from '../types';
import { analyzeAudio } from '../services/geminiService';
import { VoiceInput } from './VoiceInput';

export const FluencyScenarios: React.FC = () => {
  const [activeScenario, setActiveScenario] = useState<FluencyScenario | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const scenarios: FluencyScenario[] = [
    { id: '1', title: 'Coffee Shop Order', description: 'Order a latte and a muffin.', difficulty: 'Beginner', aiRole: 'Barista', userRole: 'Customer', prompt: 'Hi there! What can I get for you today?' },
    { id: '2', title: 'Job Interview', description: 'Introduce yourself to the hiring manager.', difficulty: 'Intermediate', aiRole: 'Interviewer', userRole: 'Candidate', prompt: 'Tell me a little about yourself and why you want this job.' },
    { id: '3', title: 'Asking for Directions', description: 'You are lost in a new city.', difficulty: 'Beginner', aiRole: 'Local', userRole: 'Tourist', prompt: 'Excuse me, you look lost. Can I help you find something?' },
    { id: '4', title: 'Project Update', description: 'Update your professor on your project.', difficulty: 'Advanced', aiRole: 'Professor', userRole: 'Student', prompt: 'So, how is your final year project coming along?' },
  ];

  const handleAudio = async (base64: string, mimeType: string) => {
    if (!activeScenario) return;
    try {
      const data = await analyzeAudio(base64, mimeType, `Scenario: ${activeScenario.title}. Prompt: ${activeScenario.prompt}`);
      setResult(data);
    } catch (e) {
      alert("Analysis failed. Try again.");
    }
  };

  const closeScenario = () => {
    setActiveScenario(null);
    setResult(null);
  };

  if (activeScenario) {
    return (
      <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
        <button onClick={closeScenario} className="text-sm font-bold text-slate-500 hover:text-primary-500 mb-4">← Back to Scenarios</button>
        
        <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-xl">
              <User size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-heading font-bold text-slate-800 dark:text-white">{activeScenario.title}</h2>
              <p className="text-slate-500">Role: {activeScenario.userRole}</p>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-2xl mb-8 border border-slate-100 dark:border-slate-800">
             <p className="text-xs font-bold uppercase text-primary-500 mb-2">{activeScenario.aiRole} says:</p>
             <p className="text-xl font-medium text-slate-800 dark:text-slate-200">"{activeScenario.prompt}"</p>
          </div>

          <div className="flex flex-col items-center justify-center gap-6">
             <p className="text-slate-500 dark:text-slate-400 font-medium text-center">Tap the mic and respond naturally.</p>
             <VoiceInput onAudioCaptured={handleAudio} iconSize={32} buttonClass="p-6" />
          </div>
        </div>

        {result && (
          <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 animate-in fade-in slide-in-from-bottom-2">
             <div className="flex items-center justify-between mb-4">
               <h3 className="font-bold text-lg text-slate-800 dark:text-white">Feedback</h3>
               <span className="text-2xl font-heading font-bold text-primary-600">{result.score}/10</span>
             </div>
             <p className="text-slate-700 dark:text-slate-300 mb-4">{result.encouragement}</p>
             
             {result.pronunciation && result.pronunciation.mispronouncedWords.length > 0 && (
               <div className="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-xl border border-orange-100 dark:border-orange-900/30">
                  <p className="text-xs font-bold uppercase text-orange-600 mb-2">Watch Out</p>
                  {result.pronunciation.mispronouncedWords.map((w, i) => (
                    <div key={i} className="text-sm text-slate-700 dark:text-slate-300">
                      <span className="font-bold">{w.word}</span>: {w.correctiveTip}
                    </div>
                  ))}
               </div>
             )}
             
             {result.fluencyMetrics && (
               <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl text-center">
                     <div className="font-bold text-slate-800 dark:text-white">{result.fluencyMetrics.wpm}</div>
                     <div className="text-[10px] uppercase text-slate-400">Words/Min</div>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl text-center">
                     <div className="font-bold text-slate-800 dark:text-white">{result.fluencyMetrics.fillersCount}</div>
                     <div className="text-[10px] uppercase text-slate-400">Fillers Used</div>
                  </div>
               </div>
             )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center py-8">
        <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">Fluency Scenarios</h1>
        <p className="text-slate-500">Practice real-life conversations in a safe environment.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {scenarios.map((scenario) => (
           <button 
             key={scenario.id} 
             onClick={() => setActiveScenario(scenario)}
             className="flex flex-col text-left bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 hover:border-primary-300 dark:hover:border-primary-700 hover:shadow-lg transition group"
           >
              <div className="flex justify-between items-start mb-4">
                 <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-xl group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50 transition">
                    <Briefcase size={20} />
                 </div>
                 <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider ${
                    scenario.difficulty === 'Beginner' ? 'bg-teal-100 text-teal-700' : 
                    scenario.difficulty === 'Intermediate' ? 'bg-orange-100 text-orange-700' : 'bg-purple-100 text-purple-700'
                 }`}>
                    {scenario.difficulty}
                 </span>
              </div>
              <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-1">{scenario.title}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4 flex-1">{scenario.description}</p>
              <div className="text-primary-600 font-bold text-sm flex items-center gap-1">
                 Start Practice <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </div>
           </button>
        ))}
      </div>
    </div>
  );
};
