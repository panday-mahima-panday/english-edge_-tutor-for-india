
import React, { useState } from 'react';
import { Send, MessageSquare, Smile, Meh, Frown, Mail, CheckCircle, Heart } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  if (sent) {
    return (
      <div className="max-w-lg mx-auto py-20 text-center animate-in zoom-in">
        <CheckCircle className="w-20 h-20 text-teal-500 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Message Sent!</h2>
        <p className="text-slate-600 dark:text-slate-400">We'll get back to you shortly.</p>
        <button onClick={() => setSent(false)} className="mt-6 text-primary-600 font-bold hover:underline">Send another</button>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">Contact Us</h1>
        <p className="text-slate-500">Have questions or suggestions? We'd love to hear from you.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Name</label>
          <input required type="text" className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-primary-500 outline-none transition" placeholder="Your Name" />
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Email</label>
          <input required type="email" className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-primary-500 outline-none transition" placeholder="your@email.com" />
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Message</label>
          <textarea required rows={4} className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-primary-500 outline-none transition resize-none" placeholder="How can we help?"></textarea>
        </div>
        <button type="submit" className="w-full py-4 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-xl font-bold shadow-lg shadow-primary-500/30 hover:shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2">
          <Send size={18} /> Send Message
        </button>
      </form>
    </div>
  );
};

export const FeedbackPage: React.FC = () => {
  const [rating, setRating] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="max-w-lg mx-auto py-20 text-center animate-in zoom-in">
        <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto mb-6 text-indigo-500">
           <Heart className="fill-current" size={40} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Thank You!</h2>
        <p className="text-slate-600 dark:text-slate-400">Your feedback helps us make English Edge better for everyone.</p>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
       <div className="text-center mb-8">
         <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">Give Feedback</h1>
         <p className="text-slate-500">How is your learning experience going?</p>
       </div>

       <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 text-center space-y-6">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">Rate your experience</label>
            <div className="flex justify-center gap-4">
               {['sad', 'neutral', 'happy'].map((mood) => (
                 <button 
                   key={mood}
                   onClick={() => setRating(mood)}
                   className={`p-4 rounded-2xl transition-all hover:scale-110 ${rating === mood ? 'bg-primary-100 dark:bg-primary-900/50 ring-2 ring-primary-500' : 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-700'}`}
                 >
                   {mood === 'sad' && <Frown size={32} className={rating === 'sad' ? 'text-primary-500' : 'text-slate-400'} />}
                   {mood === 'neutral' && <Meh size={32} className={rating === 'neutral' ? 'text-primary-500' : 'text-slate-400'} />}
                   {mood === 'happy' && <Smile size={32} className={rating === 'happy' ? 'text-primary-500' : 'text-slate-400'} />}
                 </button>
               ))}
            </div>
          </div>

          <div>
             <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 text-left">Your Suggestions</label>
             <textarea 
               className="w-full p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-primary-500 outline-none transition resize-none h-32"
               placeholder="Tell us what you like or what needs improvement..."
             ></textarea>
          </div>

          <button 
            onClick={() => setSubmitted(true)}
            disabled={!rating}
            className="w-full py-4 bg-primary-600 text-white rounded-xl font-bold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-xl hover:scale-[1.02] transition-all"
          >
            Submit Feedback
          </button>
       </div>
    </div>
  );
};