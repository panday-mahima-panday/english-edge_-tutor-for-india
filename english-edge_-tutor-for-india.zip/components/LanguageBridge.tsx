import React, { useState, useRef, useEffect } from 'react';
import { ArrowRight, Languages, Mic, Volume2, RotateCcw, PlayCircle, History, AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Loader2, Heart } from 'lucide-react';
import { translateToEnglish, evaluateBridgeAudio } from '../services/geminiService';
import { BridgeTranslation, BridgeEvaluation, BridgeHistoryItem } from '../types';

export const LanguageBridge: React.FC = () => {
  const [step, setStep] = useState<'input' | 'translation' | 'result'>('input');
  const [inputText, setInputText] = useState('');
  const [translation, setTranslation] = useState<BridgeTranslation | null>(null);
  const [evaluation, setEvaluation] = useState<BridgeEvaluation | null>(null);
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showHindiHelp, setShowHindiHelp] = useState(true);
  const [history, setHistory] = useState<BridgeHistoryItem[]>([]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Load history on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('bridge_history');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    setLoading(true);
    try {
      const result = await translateToEnglish(inputText);
      setTranslation({ ...result, originalText: inputText });
      setStep('translation');
    } catch (error) {
      alert("Failed to translate. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = handleAudioStop;
      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic error:", err);
      alert("Could not access microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleAudioStop = async () => {
    if (!translation) return;
    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
    setLoading(true);
    
    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        const result = await evaluateBridgeAudio(base64String, audioBlob.type, translation.translatedText);
        setEvaluation(result);
        setStep('result');
        
        // Save to history
        const newItem: BridgeHistoryItem = {
          id: Date.now().toString(),
          timestamp: Date.now(),
          original: translation.originalText || inputText,
          english: translation.translatedText,
          score: result.pronunciationScore
        };
        const newHistory = [newItem, ...history].slice(0, 10);
        setHistory(newHistory);
        localStorage.setItem('bridge_history', JSON.stringify(newHistory));
      };
    } catch (error) {
      console.error(error);
      alert("Failed to analyze audio.");
    } finally {
      setLoading(false);
    }
  };

  const speak = (text: string, rate = 1) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  };

  const reset = () => {
    setStep('input');
    setTranslation(null);
    setEvaluation(null);
    setInputText('');
  };

  return (
    <div className="space-y-6 md:space-y-8 max-w-5xl mx-auto h-full flex flex-col pb-4">
      {/* Header with Photo */}
      <div className="relative rounded-3xl overflow-hidden shadow-soft h-40 md:h-56 group shrink-0">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-950/90 via-indigo-900/80 to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=1000&auto=format&fit=crop" 
          alt="People connecting" 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute bottom-0 left-0 p-6 md:p-10 z-20 text-white">
           <div className="flex items-center gap-2 text-indigo-200 font-bold uppercase text-[10px] md:text-xs tracking-widest mb-2">
             <Languages size={14} className="text-indigo-400" />
             Translation & Flow
           </div>
           <h2 className="text-2xl md:text-4xl font-heading font-bold leading-tight">Language Bridge</h2>
           <p className="text-indigo-100 font-medium text-xs md:text-sm mt-1">Think in your language, speak in English.</p>
        </div>
      </div>

      {/* STEP 1: INPUT */}
      {step === 'input' && (
        <div className="space-y-6 md:space-y-8 animate-in fade-in duration-300">
          <div className="bg-surface-light dark:bg-surface-dark p-6 md:p-8 rounded-2xl shadow-soft border border-white dark:border-slate-800">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-2">
              <label className="block text-sm font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Type or speak a sentence in Hindi
              </label>
              <span className="text-xs font-bold text-primary-500 flex items-center gap-1"><Heart size={10} className="fill-current"/> Small steps make big progress</span>
            </div>
            <div className="relative group">
               <div className="absolute inset-0 bg-primary-500/10 rounded-2xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
               <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="e.g., Mera college kal band hai..."
                className="w-full h-40 md:h-52 p-5 rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-700 focus:border-primary-500 dark:focus:border-primary-500 outline-none resize-none transition-all text-lg md:text-xl font-medium relative z-10 text-text-main dark:text-white placeholder-slate-300 dark:placeholder-slate-600"
               />
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={handleTranslate}
                disabled={!inputText.trim() || loading}
                className="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-primary-DEFAULT to-primary-600 text-white rounded-full font-bold hover:shadow-glow disabled:opacity-50 transition-all flex items-center justify-center gap-2 transform active:scale-95"
              >
                {loading ? <Loader2 className="animate-spin" /> : <>Translate <ArrowRight size={20} /></>}
              </button>
            </div>
          </div>

          {/* History Snippet */}
          {history.length > 0 && (
            <div className="mt-8">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                <History size={14} /> Recent Practice
              </h3>
              <div className="grid gap-3 sm:grid-cols-2 opacity-90">
                {history.slice(0, 4).map((item) => (
                  <div key={item.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl flex justify-between items-center text-sm shadow-sm border border-slate-100 dark:border-slate-700 transition-hover hover:scale-[1.01]">
                    <div className="truncate flex-1 pr-4">
                      <p className="font-bold text-slate-800 dark:text-slate-200 truncate text-base">{item.english}</p>
                      <p className="text-slate-500 text-xs truncate mt-0.5">{item.original}</p>
                    </div>
                    <span className={`font-heading font-bold text-lg ${item.score >= 80 ? 'text-teal-500' : 'text-indigo-400'}`}>
                      {item.score}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* STEP 2: TRANSLATION & PRACTICE */}
      {step === 'translation' && translation && (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
          
          <div className="grid gap-6 md:grid-cols-2">
             {/* Card: Original -> English */}
             <div className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 overflow-hidden flex flex-col">
                <div className="p-5 md:p-6 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800">
                   <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Original</span>
                   <p className="text-lg md:text-xl text-slate-700 dark:text-slate-300 mt-2 font-medium">{translation.originalText}</p>
                </div>
                <div className="p-6 md:p-8 bg-gradient-to-br from-[#5B6DFF] to-[#7A88FF] text-white relative overflow-hidden group flex-1">
                   <div className="absolute top-0 right-0 p-4 opacity-10 transform group-hover:scale-125 transition-transform duration-700"><Languages size={80} /></div>
                   <span className="text-[10px] font-bold text-white/70 uppercase tracking-widest">Natural English</span>
                   <p className="text-2xl md:text-3xl font-heading font-bold mt-3 leading-tight relative z-10 drop-shadow-sm">{translation.translatedText}</p>
                   <button 
                     onClick={() => speak(translation.translatedText)}
                     className="mt-6 flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-md px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm"
                   >
                      <Volume2 size={18} /> Listen
                   </button>
                </div>
             </div>

             {/* Explanation Accordion */}
             <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm flex flex-col">
                <div className="p-5 border-b border-slate-100 dark:border-slate-700 bg-indigo-50/50 dark:bg-slate-800/50 flex items-start gap-4">
                   <div className="mt-1 text-indigo-500 p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-full shrink-0"><AlertCircle size={20} /></div>
                   <div>
                      <h4 className="font-heading font-bold text-slate-800 dark:text-slate-200 text-lg">Why this translation?</h4>
                      <p className="text-slate-600 dark:text-slate-400 text-sm mt-1 font-medium leading-relaxed">{translation.explanation}</p>
                   </div>
                </div>
                {showHindiHelp && translation.hindiExplanation && (
                  <div className="p-5 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-200 text-sm border-t border-indigo-100 dark:border-indigo-800/30 flex gap-2 items-start flex-1">
                    <span className="font-bold bg-indigo-100 dark:bg-indigo-900/50 px-2 py-0.5 rounded text-xs uppercase tracking-wide mt-0.5 shrink-0">Hint</span> 
                    <span className="font-medium leading-relaxed">{translation.hindiExplanation}</span>
                  </div>
                )}
             </div>
          </div>

          {/* Recording Action */}
          <div className="text-center pt-4 md:pt-6">
             {loading ? (
                <div className="flex flex-col items-center gap-4 text-slate-500">
                  <Loader2 className="animate-spin w-12 h-12 text-primary-500" />
                  <p className="font-bold animate-pulse">Analyzing your speech...</p>
                </div>
             ) : (
               <>
                <p className="text-slate-500 dark:text-slate-400 mb-6 md:mb-8 font-medium">Now, tap the mic and speak the English sentence.</p>
                <div className="flex justify-center items-center gap-6 md:gap-8">
                   <button
                     onClick={reset}
                     className="p-3 md:p-4 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-600 transition-all"
                     title="Reset"
                   >
                     <RotateCcw className="w-5 h-5 md:w-6 md:h-6" />
                   </button>
                   <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`p-6 md:p-8 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 ${
                      isRecording 
                        ? 'bg-indigo-500 text-white ring-8 ring-indigo-100 dark:ring-indigo-900 animate-pulse' 
                        : 'bg-gradient-to-r from-primary-DEFAULT to-primary-600 text-white ring-8 ring-primary-100 dark:ring-primary-900/20 shadow-primary-500/30'
                    }`}
                   >
                     {isRecording ? <div className="w-6 h-6 md:w-8 md:h-8 rounded-sm bg-white" /> : <Mic className="w-7 h-7 md:w-9 md:h-9" />}
                   </button>
                   <div className="w-10 md:w-14"></div> {/* Spacer for visual balance */}
                </div>
               </>
             )}
          </div>
        </div>
      )}

      {/* STEP 3: RESULTS */}
      {step === 'result' && evaluation && translation && (
        <div className="space-y-6 md:space-y-8 animate-in slide-in-from-bottom-8 duration-500">
           
           <div className="grid gap-6 md:grid-cols-3">
             {/* Score Card */}
             <div className="md:col-span-1 bg-surface-light dark:bg-surface-dark p-6 md:p-8 rounded-2xl shadow-soft border border-white dark:border-slate-800 text-center relative overflow-hidden flex flex-col justify-center">
                <div className="relative z-10">
                  <div className="inline-flex items-center justify-center w-24 h-24 md:w-32 md:h-32 rounded-full border-8 border-primary-100 dark:border-slate-800 text-4xl md:text-5xl font-heading font-bold text-primary-600 dark:text-primary-400 mb-3 bg-white dark:bg-slate-900 shadow-lg">
                    {evaluation.pronunciationScore}
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px] md:text-xs tracking-widest">Pronunciation Score</p>
                  
                  <div className="mt-4 md:mt-6 p-4 md:p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                    <p className="text-slate-700 dark:text-slate-300 italic font-medium text-sm md:text-base">"{evaluation.feedback}"</p>
                  </div>
                </div>
             </div>

             {/* Mistake Breakdown */}
             <div className="md:col-span-2 bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 p-6 md:p-8">
               <h3 className="font-heading font-bold text-slate-800 dark:text-white mb-5 flex items-center gap-2 text-lg">
                 <AlertCircle className="text-indigo-400" size={22} /> Areas to Improve
               </h3>
               
               {evaluation.mispronouncedWords.length > 0 ? (
                 <div className="space-y-3">
                   {evaluation.mispronouncedWords.map((word, idx) => (
                     <div key={idx} className="flex justify-between items-center p-3 md:p-4 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 md:gap-3">
                            <span className="font-heading font-bold text-indigo-500 text-lg md:text-xl">{word.word}</span>
                            <span className="text-xs bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 text-slate-500 font-mono tracking-wide">/{word.ipa}/</span>
                          </div>
                          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 font-medium">{word.correctiveTip}</p>
                        </div>
                        <button 
                          onClick={() => speak(word.word, 0.7)}
                          className="p-2.5 md:p-3 bg-primary-50 dark:bg-slate-800 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-slate-700 rounded-full transition shadow-sm shrink-0"
                        >
                          <Volume2 className="w-[18px] h-[18px] md:w-5 md:h-5" />
                        </button>
                     </div>
                   ))}
                 </div>
               ) : (
                 <div className="text-teal-600 dark:text-teal-400 flex items-center gap-3 font-bold bg-teal-50 dark:bg-teal-900/20 p-5 rounded-xl border border-teal-100 dark:border-teal-900/30">
                   <CheckCircle2 size={24} /> No major mispronunciations found!
                 </div>
               )}
             </div>
           </div>

           {/* Playback Controls */}
           <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => speak(translation.translatedText, 0.7)}
                className="flex-1 bg-white dark:bg-surface-dark py-4 rounded-xl shadow-soft border border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center justify-center gap-2 group"
              >
                <PlayCircle size={20} className="group-hover:scale-110 transition-transform" /> Slow Audio
              </button>
              <button 
                onClick={reset}
                className="flex-1 bg-gradient-to-r from-primary-DEFAULT to-primary-600 py-4 rounded-xl shadow-lg shadow-primary-500/30 font-bold text-white hover:shadow-glow transition flex items-center justify-center gap-2 transform active:scale-95"
              >
                <RotateCcw size={20} /> New Sentence
              </button>
           </div>
        </div>
      )}
    </div>
  );
};