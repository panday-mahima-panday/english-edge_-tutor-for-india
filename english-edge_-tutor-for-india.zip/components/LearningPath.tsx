
import React from 'react';
import { Map, Lock, PlayCircle, CheckCircle2, Star } from 'lucide-react';
import { PathLevel } from '../types';

export const LearningPath: React.FC = () => {
  const learningPath: PathLevel[] = [
    {
      id: 'beginner',
      name: 'Beginner',
      description: 'Master the basics of daily speech',
      status: 'completed',
      progress: 100,
      tasks: [
        { title: 'Master Basic Greetings', description: 'Learn 10 common ways to say hello', duration: '5 min' },
        { title: 'Present Simple Tense', description: 'Talk about your daily routine', duration: '10 min' },
      ]
    },
    {
      id: 'intermediate',
      name: 'Intermediate',
      description: 'Conversational fluency & storytelling',
      status: 'active',
      progress: 45,
      tasks: [
        { title: 'Past Tense Practice', description: 'Narrate a past event clearly', duration: '15 min' },
        { title: 'Travel Vocabulary', description: 'Booking hotels and asking directions', duration: '10 min' },
        { title: 'Expressing Opinions', description: 'Agreeing and disagreeing politely', duration: '12 min' },
      ]
    },
    {
      id: 'advanced',
      name: 'Advanced',
      description: 'Professional contexts & complex structures',
      status: 'locked',
      progress: 0,
      tasks: [
        { title: 'Job Interview Prep', description: 'Answering behavioral questions', duration: '20 min' },
        { title: 'Complex Clauses', description: 'Using although, despite, whereas', duration: '15 min' },
      ]
    },
    {
      id: 'mastery',
      name: 'Mastery',
      description: 'Native-level nuance, idioms, and style',
      status: 'locked',
      progress: 0,
      tasks: [
        { title: 'Idioms & Phrasal Verbs', description: 'Sounding like a local', duration: '20 min' },
        { title: 'Accent Refinement', description: 'Intonation and stress patterns', duration: '25 min' },
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center py-8">
        <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">Your Learning Journey</h1>
        <p className="text-slate-500">Follow the path to English mastery step by step.</p>
      </div>

      <div className="relative">
         {/* Connector Line */}
         <div className="absolute left-6 md:left-10 top-0 bottom-0 w-1 bg-gradient-to-b from-primary-500 to-indigo-200 dark:from-primary-600 dark:to-slate-800 rounded-full"></div>

         <div className="space-y-8">
            {learningPath.map((level, idx) => (
              <div key={level.id} className="relative pl-16 md:pl-24">
                 {/* Timeline Node */}
                 <div className={`
                    absolute left-2 md:left-6 top-6 w-9 h-9 md:w-9 md:h-9 rounded-full border-4 border-white dark:border-slate-900 shadow-lg z-10 flex items-center justify-center
                    ${level.status === 'completed' ? 'bg-teal-500 text-white' : level.status === 'active' ? 'bg-primary-500 text-white animate-pulse' : 'bg-slate-200 dark:bg-slate-700 text-slate-400'}
                 `}>
                    {level.status === 'completed' ? <CheckCircle2 size={16} /> : level.status === 'active' ? <Star size={16} className="fill-current" /> : <Lock size={16} />}
                 </div>

                 <div className={`bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 overflow-hidden transition-all duration-300 ${level.status === 'active' ? 'ring-2 ring-primary-500 ring-offset-2 dark:ring-offset-slate-900' : 'opacity-90'}`}>
                    <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-start">
                       <div>
                          <div className="flex items-center gap-3 mb-1">
                             <h3 className="text-xl font-heading font-bold text-slate-800 dark:text-white">{level.name}</h3>
                             <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                level.status === 'completed' ? 'bg-teal-100 text-teal-700' : level.status === 'active' ? 'bg-primary-100 text-primary-700' : 'bg-slate-100 text-slate-500'
                             }`}>
                                {level.status}
                             </span>
                          </div>
                          <p className="text-slate-500 text-sm font-medium">{level.description}</p>
                       </div>
                       <div className="text-right hidden sm:block">
                          <span className="text-2xl font-bold text-slate-800 dark:text-white">{level.progress}%</span>
                       </div>
                    </div>
                    
                    <div className="p-2">
                       {level.tasks.map((task, tIdx) => (
                         <div key={tIdx} className="flex items-center gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl transition group cursor-pointer">
                            <div className={`p-3 rounded-full ${level.status === 'locked' ? 'bg-slate-100 dark:bg-slate-800 text-slate-300' : 'bg-primary-50 dark:bg-primary-900/20 text-primary-600'}`}>
                               <PlayCircle size={20} />
                            </div>
                            <div className="flex-1">
                               <h4 className={`font-bold text-sm md:text-base ${level.status === 'locked' ? 'text-slate-400' : 'text-slate-700 dark:text-slate-200'}`}>{task.title}</h4>
                               <p className="text-xs text-slate-500">{task.description}</p>
                            </div>
                            <span className="text-xs font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">{task.duration}</span>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>
            ))}
         </div>
      </div>
    </div>
  );
};
