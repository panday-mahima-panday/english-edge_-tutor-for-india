
import React from 'react';

export const Logo: React.FC<{ className?: string, showText?: boolean }> = ({ className = "w-32 h-10", showText = true }) => {
  return (
    <div className="flex items-center gap-2 select-none">
      <svg className={className} viewBox={showText ? "0 0 180 60" : "0 0 50 60"} fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
        <defs>
          {/* Vertical Gradient: Saffron (Top) -> Lavender (Bottom) */}
          <linearGradient id="creatorGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FF9933" /> {/* Saffron/Warm */}
            <stop offset="50%" stopColor="#818CF8" /> {/* Transition */}
            <stop offset="100%" stopColor="#5B6DFF" /> {/* Lavender/Cool */}
          </linearGradient>
          
          {/* Soft Glow Filter */}
          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        <g>
           {/* Tilak Accent - positioned over the C */}
           <path 
             d="M17 12 L17 20" 
             stroke="#FF9933" 
             strokeWidth="3" 
             strokeLinecap="round"
             filter="url(#softGlow)"
           />
           
           {/* Text */}
           {showText ? (
             <text x="2" y="52" fontFamily="Poppins, sans-serif" fontWeight="700" fontSize="44" fill="url(#creatorGradient)" filter="url(#softGlow)" letterSpacing="-0.02em">
               Creater
             </text>
           ) : (
             <text x="2" y="52" fontFamily="Poppins, sans-serif" fontWeight="700" fontSize="44" fill="url(#creatorGradient)" filter="url(#softGlow)">
               C
             </text>
           )}
        </g>
      </svg>
      <span className="sr-only">Creater</span>
    </div>
  );
};
