
import React, { useState } from 'react';
import { User, Edit2, Crown, Target, Zap, Camera, PenTool, Mic } from 'lucide-react';
import { UserProfile } from '../types';

export const Profile: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    name: "Student",
    avatar: "🎓",
    learningGoal: "Job Interview",
    englishLevel: "Intermediate",
    dailyTarget: 20,
    focusArea: 'both'
  });

  const handleSave = () => setIsEditing(false);

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
      {/* Profile Header */}
      <div className="relative bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-8 text-white shadow-glow overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-10"><Crown size={120} /></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
          <div className="relative group">
            <div className="w-24 h-24 rounded-full bg-white text-4xl flex items-center justify-center shadow-lg border-4 border-white/30">
              {profile.avatar}
            </div>
            <button className="absolute bottom-0 right-0 p-2 bg-slate-900 text-white rounded-full hover:bg-black transition shadow-sm">
               <Camera size={14} />
            </button>
          </div>
          <div>
            {isEditing ? (
              <input 
                value={profile.name} 
                onChange={(e) => setProfile({...profile, name: e.target.value})}
                className="bg-white/20 text-white font-bold text-2xl p-2 rounded border border-white/30 outline-none w-full mb-2"
              />
            ) : (
              <h1 className="text-3xl font-heading font-bold">{profile.name}</h1>
            )}
            <p className="text-indigo-100 font-medium opacity-90">Ready to learn today?</p>
          </div>
          <div className="ml-auto">
             {!isEditing ? (
               <button onClick={() => setIsEditing(true)} className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-full text-sm font-bold backdrop-blur-sm transition">
                 Edit Profile
               </button>
             ) : (
               <button onClick={handleSave} className="px-6 py-2 bg-white text-indigo-600 rounded-full text-sm font-bold shadow-sm transition">
                 Save Changes
               </button>
             )}
          </div>
        </div>
      </div>

      {/* Focus Area Selection */}
      <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800">
         <h3 className="font-bold text-slate-800 dark:text-white mb-4">Focus Area</h3>
         <div className="flex gap-4">
            {['speaking', 'writing', 'both'].map((type) => (
               <button 
                  key={type}
                  onClick={() => isEditing && setProfile({...profile, focusArea: type as any})}
                  disabled={!isEditing}
                  className={`flex-1 p-4 rounded-xl border flex flex-col items-center gap-2 transition ${
                     profile.focusArea === type 
                     ? 'bg-primary-50 border-primary-500 text-primary-600 dark:bg-primary-900/20' 
                     : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-500'
                  }`}
               >
                  {type === 'speaking' && <Mic size={24} />}
                  {type === 'writing' && <PenTool size={24} />}
                  {type === 'both' && <div className="flex"><Mic size={20}/><PenTool size={20}/></div>}
                  <span className="capitalize font-bold text-sm">{type}</span>
               </button>
            ))}
         </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 flex flex-col items-center justify-center text-center">
           <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 text-orange-500 flex items-center justify-center mb-3">
             <Zap size={20} />
           </div>
           <span className="text-2xl font-bold text-slate-800 dark:text-white">{profile.dailyTarget}m</span>
           <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Daily Target</span>
        </div>
        <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 flex flex-col items-center justify-center text-center">
           <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-500 flex items-center justify-center mb-3">
             <Target size={20} />
           </div>
           {isEditing ? (
             <select 
               value={profile.learningGoal}
               onChange={(e) => setProfile({...profile, learningGoal: e.target.value})}
               className="bg-slate-100 dark:bg-slate-800 text-xs p-1 rounded"
             >
               <option>Job Interview</option>
               <option>Travel</option>
               <option>General</option>
             </select>
           ) : (
             <span className="text-lg font-bold text-slate-800 dark:text-white truncate max-w-full">{profile.learningGoal}</span>
           )}
           <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Main Goal</span>
        </div>
        <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 flex flex-col items-center justify-center text-center">
           <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-500 flex items-center justify-center mb-3">
             <Crown size={20} />
           </div>
           {isEditing ? (
             <select 
               value={profile.englishLevel}
               onChange={(e) => setProfile({...profile, englishLevel: e.target.value})}
               className="bg-slate-100 dark:bg-slate-800 text-xs p-1 rounded"
             >
               <option>Beginner</option>
               <option>Intermediate</option>
               <option>Advanced</option>
             </select>
           ) : (
             <span className="text-lg font-bold text-slate-800 dark:text-white">{profile.englishLevel}</span>
           )}
           <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Current Level</span>
        </div>
      </div>
    </div>
  );
};
