import React, { useEffect, useState } from 'react';
import { TrendingUp, Award, Zap, Activity, Heart, Smile, Calendar, ArrowUpRight } from 'lucide-react';
import { ProgressRecord } from '../types';

export const ProgressTracker: React.FC = () => {
  const [history, setHistory] = useState<ProgressRecord[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('user_progress_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Sort by date descending
        setHistory(parsed.sort((a: ProgressRecord, b: ProgressRecord) => b.date - a.date));
      } catch (e) {
        console.error("Failed to load progress history");
      }
    }
  }, []);

  // Calculate trends
  const calculateAverage = (key: keyof ProgressRecord) => {
    if (history.length === 0) return 0;
    const sum = history.reduce((acc, curr) => acc + (curr[key] as number), 0);
    return Math.round(sum / history.length);
  };

  const pronScore = calculateAverage('pronunciationScore');
  const fluencyScore = calculateAverage('fluencyScore');
  const grammarScore = calculateAverage('grammarScore');

  // Positivity Coach Logic
  const getCoachMessage = () => {
    if (history.length === 0) return "Welcome! Start your first lesson to see your progress bloom.";
    const latest = history[0];
    if (latest.overallScore > 8) return "You are on fire! Your latest session was outstanding.";
    if (latest.overallScore > 5) return "Consistent progress! You're building strong habits.";
    return "Every expert was once a beginner. Keep showing up!";
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500 pb-10">
      
      {/* Header */}
      <div className="relative rounded-3xl overflow-hidden shadow-soft h-48 md:h-64 group">
         <div className="absolute inset-0 bg-gradient-to-r from-indigo-950/90 via-purple-900/80 to-transparent z-10 mix-blend-multiply"></div>
         <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/80 to-transparent z-10"></div>
         <img 
           src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=1000&auto=format&fit=crop" 
           alt="Progress Growth" 
           className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
         />
         <div className="absolute bottom-0 left-0 p-6 md:p-10 z-20 text-white">
            <div className="flex items-center gap-2 text-indigo-200 font-bold uppercase text-[10px] md:text-xs tracking-widest mb-2">
              <Activity size={14} className="text-indigo-400" />
              Progress Dashboard
            </div>
            <h2 className="text-3xl md:text-5xl font-heading font-bold leading-tight">Your Growth<br/>Journey</h2>
         </div>
      </div>

      {/* Positivity Coach */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 rounded-2xl p-6 md:p-8 shadow-glow text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 md:p-10 opacity-10"><Heart className="w-20 h-20 md:w-[100px] md:h-[100px]" /></div>
        <div className="relative z-10 flex flex-col md:flex-row gap-4 items-start">
           <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm shrink-0">
             <Smile size={32} />
           </div>
           <div>
             <h3 className="font-heading font-bold text-lg mb-1">Positivity Coach</h3>
             <p className="font-medium opacity-95 text-lg leading-relaxed">"{getCoachMessage()}"</p>
             <div className="flex flex-wrap gap-2 mt-4">
               <span className="text-[10px] font-bold bg-white/20 px-3 py-1 rounded-full">Safe Space</span>
               <span className="text-[10px] font-bold bg-white/20 px-3 py-1 rounded-full">No Judgement</span>
               <span className="text-[10px] font-bold bg-white/20 px-3 py-1 rounded-full">Growth Mindset</span>
             </div>
           </div>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
         <StatCard title="Pronunciation" score={pronScore} max={100} icon={<Award size={20}/>} suffix="%" color="from-teal-400 to-teal-600" />
         <StatCard title="Grammar" score={grammarScore} max={100} icon={<Activity size={20}/>} suffix="%" color="from-blue-400 to-blue-600" />
         <StatCard title="Fluency" score={fluencyScore} max={10} icon={<Zap size={20}/>} suffix="/10" color="from-purple-400 to-purple-600" />
         <StatCard title="Consistency" score={history.length} max={50} icon={<TrendingUp size={20}/>} suffix=" Sessions" color="from-pink-400 to-pink-600" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Graphs Section */}
        <div className="lg:col-span-2 bg-surface-light dark:bg-surface-dark rounded-2xl p-6 md:p-8 shadow-soft border border-white dark:border-slate-800">
          <h3 className="font-heading font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2">
              <TrendingUp className="text-primary-500" /> Performance Over Time
          </h3>
          
          {history.length > 0 ? (
            <div className="h-64 flex items-end justify-between gap-2 md:gap-4 px-2">
                {history.slice(0, 10).reverse().map((record, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 group relative">
                      {/* Tooltip */}
                      <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 text-white text-xs p-2 rounded pointer-events-none whitespace-nowrap z-20">
                        Score: {record.overallScore}/10
                      </div>
                      
                      <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-t-xl relative h-full overflow-hidden">
                        <div 
                          className="absolute bottom-0 w-full bg-gradient-to-t from-primary-600 to-primary-400 dark:from-primary-700 dark:to-primary-500 rounded-t-xl transition-all duration-1000 group-hover:brightness-110"
                          style={{ height: `${record.overallScore * 10}%` }}
                        ></div>
                      </div>
                      <span className="text-[9px] md:text-[10px] text-slate-400 font-bold">{new Date(record.date).getDate()}/{new Date(record.date).getMonth()+1}</span>
                  </div>
                ))}
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-400 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-dashed border-slate-300 dark:border-slate-700">
                <p>Complete your first practice to see graphs!</p>
            </div>
          )}
        </div>

        {/* Recent Activity List */}
        <div className="bg-surface-light dark:bg-surface-dark rounded-2xl p-6 shadow-soft border border-white dark:border-slate-800 flex flex-col">
          <h3 className="font-heading font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-4">
            <Calendar className="text-indigo-400" size={18} /> Recent History
          </h3>
          <div className="space-y-3 flex-1 overflow-y-auto max-h-[400px] no-scrollbar">
            {history.length > 0 ? (
              history.slice(0, 6).map((record) => (
                <div key={record.id} className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm flex justify-between items-center transition hover:scale-[1.02]">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full">
                          {record.type === 'speaking' ? <Award size={18} /> : <TrendingUp size={18} />}
                      </div>
                      <div className="min-w-0">
                          <p className="font-bold text-slate-700 dark:text-slate-200 capitalize text-sm truncate">{record.type} Practice</p>
                          <p className="text-[10px] text-slate-500">{new Date(record.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 pl-2">
                      <span className="text-lg font-heading font-bold text-primary-600 dark:text-primary-400">{record.overallScore}</span>
                      <span className="text-[9px] text-slate-400 uppercase font-bold">/ 10</span>
                    </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-500 text-sm">No activity yet. Start practicing!</div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
};

const StatCard: React.FC<{ title: string, score: number, max: number, icon: React.ReactNode, suffix: string, color: string }> = ({ title, score, max, icon, suffix, color }) => (
   <div className="bg-surface-light dark:bg-surface-dark p-5 rounded-2xl shadow-soft border border-white dark:border-slate-800 relative overflow-hidden group hover:-translate-y-1 transition-transform duration-300">
      <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-[10px] uppercase font-bold tracking-widest mb-2">
         {icon} {title}
      </div>
      <div className="flex items-baseline gap-1 relative z-10">
         <span className={`text-3xl font-heading font-bold bg-clip-text text-transparent bg-gradient-to-r ${color}`}>
            {score}
         </span>
         <span className="text-[10px] text-slate-400 font-bold">{suffix}</span>
      </div>
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
         <div className={`h-full rounded-full bg-gradient-to-r ${color}`} style={{ width: `${(score / max) * 100}%` }}></div>
      </div>
   </div>
);