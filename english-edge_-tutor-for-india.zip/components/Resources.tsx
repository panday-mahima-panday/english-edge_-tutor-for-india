
import React from 'react';
import { FileText, BookOpen, Mic, MessageSquare, Download, ArrowRight, PlayCircle, Volume2 } from 'lucide-react';
import { ResourceItem } from '../types';
import { VoiceInput } from './VoiceInput';

export const Resources: React.FC = () => {
  const resources: ResourceItem[] = [
    { id: '1', title: 'Top 100 Business Phrasal Verbs', type: 'vocab', description: 'Essential verbs for corporate jobs.', content: 'PDF' },
    { id: '2', title: 'IELTS Speaking Part 2 Templates', type: 'speaking', description: 'Structure your answers perfectly.', content: 'Guide' },
    { id: '3', title: 'Mastering Prepositions', type: 'grammar', description: 'Rules for in, on, at, by, and for.', content: 'Article' },
    { id: '4', title: 'Job Interview Q&A Cheatsheet', type: 'interview', description: 'Common questions and smart answers.', content: 'PDF' },
    { id: '5', title: 'Daily Routine Vocabulary', type: 'vocab', description: 'Words to describe your day.', content: 'List' },
    { id: '6', title: 'Intonation Patterns Guide', type: 'speaking', description: 'How to sound more natural.', content: 'Audio' },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'vocab': return <BookOpen size={20} />;
      case 'grammar': return <FileText size={20} />;
      case 'speaking': return <Mic size={20} />;
      case 'interview': return <MessageSquare size={20} />;
      default: return <FileText size={20} />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'vocab': return 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400';
      case 'grammar': return 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400';
      case 'speaking': return 'bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400';
      case 'interview': return 'bg-teal-100 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
       <div className="text-center py-8">
         <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">Study Resources</h1>
         <p className="text-slate-500">Curated materials to boost your English skills.</p>
       </div>

       <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {resources.map((item) => (
             <div key={item.id} className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800 hover:shadow-lg transition group flex flex-col">
                <div className="flex justify-between items-start mb-4">
                   <div className={`p-3 rounded-xl ${getColor(item.type)}`}>
                      {getIcon(item.type)}
                   </div>
                   <button className="text-slate-400 hover:text-primary-500 transition">
                      <Download size={20} />
                   </button>
                </div>
                <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-2 leading-snug">{item.title}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 flex-1">{item.description}</p>
                
                <div className="flex gap-2 mt-auto">
                    <button onClick={() => speak(item.title)} className="flex-1 py-2 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100 transition flex items-center justify-center gap-1">
                       <Volume2 size={14} /> Listen
                    </button>
                    <div className="flex-1 flex justify-center">
                        <VoiceInput onAudioCaptured={() => alert("Practice recorded!")} buttonClass="w-8 h-8" iconSize={14} />
                    </div>
                </div>
             </div>
          ))}
       </div>
    </div>
  );
};
