
import React, { useState } from 'react';
import { Moon, Sun, Bell, Volume2, Shield, HelpCircle, LogOut, ChevronRight, User } from 'lucide-react';
import { Logo } from './Logo';

export const Settings: React.FC = () => {
  const [notifications, setNotifications] = useState(true);
  const [sound, setSound] = useState(true);

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-6">Settings</h1>

      {/* Account Section */}
      <section className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 overflow-hidden">
        <h3 className="bg-slate-50 dark:bg-slate-800/50 px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-500">Account</h3>
        <div className="p-2">
           <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition group">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-primary-50 dark:bg-primary-900/20 text-primary-600 rounded-lg"><User size={20} /></div>
                 <span className="font-medium text-slate-700 dark:text-slate-300">Edit Profile</span>
              </div>
              <ChevronRight size={16} className="text-slate-300 group-hover:text-primary-500" />
           </button>
        </div>
      </section>

      {/* Preferences */}
      <section className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 overflow-hidden">
        <h3 className="bg-slate-50 dark:bg-slate-800/50 px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-500">Preferences</h3>
        <div className="p-2 space-y-1">
           <div className="flex items-center justify-between p-4 rounded-xl">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-orange-50 dark:bg-orange-900/20 text-orange-600 rounded-lg"><Bell size={20} /></div>
                 <span className="font-medium text-slate-700 dark:text-slate-300">Notifications</span>
              </div>
              <button 
                onClick={() => setNotifications(!notifications)}
                className={`w-12 h-6 rounded-full transition-colors relative ${notifications ? 'bg-primary-500' : 'bg-slate-200 dark:bg-slate-700'}`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${notifications ? 'left-7' : 'left-1'}`}></div>
              </button>
           </div>
           <div className="flex items-center justify-between p-4 rounded-xl">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-teal-50 dark:bg-teal-900/20 text-teal-600 rounded-lg"><Volume2 size={20} /></div>
                 <span className="font-medium text-slate-700 dark:text-slate-300">Sound Effects</span>
              </div>
              <button 
                onClick={() => setSound(!sound)}
                className={`w-12 h-6 rounded-full transition-colors relative ${sound ? 'bg-primary-500' : 'bg-slate-200 dark:bg-slate-700'}`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${sound ? 'left-7' : 'left-1'}`}></div>
              </button>
           </div>
        </div>
      </section>

      {/* Support & About */}
      <section className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-soft border border-white dark:border-slate-800 overflow-hidden">
        <h3 className="bg-slate-50 dark:bg-slate-800/50 px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-500">Support</h3>
        <div className="p-2 space-y-1">
           <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition group">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-lg"><HelpCircle size={20} /></div>
                 <span className="font-medium text-slate-700 dark:text-slate-300">Help & FAQ</span>
              </div>
              <ChevronRight size={16} className="text-slate-300 group-hover:text-primary-500" />
           </button>
           <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition group">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-purple-50 dark:bg-purple-900/20 text-purple-600 rounded-lg"><Shield size={20} /></div>
                 <span className="font-medium text-slate-700 dark:text-slate-300">Privacy & Terms</span>
              </div>
              <ChevronRight size={16} className="text-slate-300 group-hover:text-primary-500" />
           </button>
        </div>
      </section>
      
      <div className="pt-6 flex flex-col items-center">
         <Logo className="w-10 h-10 mb-2 opacity-50" />
         <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">English Edge v1.0.0</p>
         <button className="mt-6 flex items-center gap-2 text-red-500 font-bold text-sm bg-red-50 dark:bg-red-900/20 px-6 py-3 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 transition">
           <LogOut size={16} /> Sign Out
         </button>
      </div>
    </div>
  );
};
