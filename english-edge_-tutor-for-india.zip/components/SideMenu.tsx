
import React from 'react';
import { 
  BookOpen, Mic, Languages, MessageCircle, TrendingUp, 
  Map, Lightbulb, Star, Heart, Trophy, FileText, 
  User, Settings, HelpCircle, FileQuestion, Mail, MessageSquare, Shield, Info, Sparkles, X, Crown,
  LogOut, Moon, Sun, Bell, Download, Users, Share2, AlertTriangle, FileCheck, StickyNote, RotateCcw, Zap, Layout, Coffee
} from 'lucide-react';
import { AppTab, UserProfile } from '../types';
import { Logo } from './Logo';

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  isMobile: boolean;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export const SideMenu: React.FC<SideMenuProps> = ({ isOpen, onClose, activeTab, onTabChange, isMobile, isDarkMode, toggleTheme }) => {
  // Mock User Profile for the card
  const user: UserProfile = {
    name: "Student",
    avatar: "🎓",
    learningGoal: "Fluency",
    englishLevel: "Intermediate",
    dailyTarget: 20
  };

  const menuGroups = [
    {
      title: "Main Navigation",
      items: [
        { id: 'practice', label: 'Home / Daily', icon: <Layout size={18} /> },
        { id: 'analyze', label: 'Analyze Speech', icon: <Mic size={18} /> },
        { id: 'bridge', label: 'Language Bridge', icon: <Languages size={18} /> },
        { id: 'chat', label: 'AI Coach', icon: <MessageCircle size={18} /> },
        { id: 'progress', label: 'Dashboard', icon: <TrendingUp size={18} /> },
      ]
    },
    {
      title: "Learning Features",
      items: [
        { id: 'learning-path', label: 'Learning Path', icon: <Map size={18} /> },
        { id: 'fluency-scenarios', label: 'Fluency Scenarios', icon: <Coffee size={18} /> },
        { id: 'insights', label: 'Mistake Insights', icon: <Lightbulb size={18} /> },
        { id: 'strengths', label: 'My Strengths', icon: <Star size={18} /> },
        { id: 'positivity', label: 'Positivity Coach', icon: <Heart size={18} /> },
        { id: 'achievements', label: 'Achievements', icon: <Trophy size={18} /> },
        { id: 'resources', label: 'Resources', icon: <FileText size={18} /> },
        { id: 'flashcards', label: 'Flashcards', icon: <Zap size={18} /> },
        { id: 'quizzes', label: 'Quizzes', icon: <FileCheck size={18} /> },
        { id: 'notes', label: 'Saved Notes', icon: <StickyNote size={18} /> },
        { id: 'recent', label: 'Recent Practice', icon: <RotateCcw size={18} /> },
      ]
    },
    {
      title: "User Tools",
      items: [
        { id: 'profile', label: 'My Profile', icon: <User size={18} /> },
        { id: 'goals', label: 'Learning Goals', icon: <TrendingUp size={18} /> },
        { id: 'notifications', label: 'Notifications', icon: <Bell size={18} /> },
        { id: 'saved-chats', label: 'Saved Chats', icon: <MessageSquare size={18} /> },
        { id: 'downloads', label: 'Downloads', icon: <Download size={18} /> },
        { id: 'subscription', label: 'Subscription', icon: <Crown size={18} /> },
        { id: 'invite', label: 'Invite Friends', icon: <Users size={18} /> },
        { id: 'share', label: 'Share App', icon: <Share2 size={18} /> },
      ]
    },
    {
      title: "Support",
      items: [
        { id: 'faq', label: 'FAQ', icon: <FileQuestion size={18} /> },
        { id: 'help', label: 'Help & Support', icon: <HelpCircle size={18} /> },
        { id: 'contact', label: 'Contact Us', icon: <Mail size={18} /> },
        { id: 'feedback', label: 'Feedback', icon: <MessageSquare size={18} /> },
        { id: 'report', label: 'Report Issue', icon: <AlertTriangle size={18} /> },
        { id: 'safety', label: 'Safety Center', icon: <Shield size={18} /> },
        { id: 'guidelines', label: 'Guidelines', icon: <FileCheck size={18} /> },
      ]
    },
    {
      title: "Legal & Info",
      items: [
        { id: 'privacy', label: 'Privacy Policy', icon: <Shield size={18} /> },
        { id: 'terms', label: 'Terms of Service', icon: <FileText size={18} /> },
        { id: 'app-info', label: 'App Info', icon: <Info size={18} /> },
        { id: 'about', label: 'About Creator', icon: <Sparkles size={18} /> },
      ]
    }
  ];

  const handleNav = (tab: AppTab) => {
    onTabChange(tab);
    if (isMobile) onClose();
  };

  // Overlay for mobile
  if (isMobile && !isOpen) return null;

  return (
    <>
      {/* Mobile Overlay */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 transition-opacity" 
          onClick={onClose}
        ></div>
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed top-0 left-0 h-full w-[300px] md:w-[320px] bg-white/95 dark:bg-[#1A1F35]/95 backdrop-blur-2xl border-r border-indigo-50 dark:border-slate-800 z-50 
        transform transition-transform duration-300 ease-in-out shadow-2xl flex flex-col
        ${isMobile ? (isOpen ? 'translate-x-0' : '-translate-x-full') : 'translate-x-0'}
      `}>
        {/* User Profile Card Header */}
        <div className="p-6 bg-gradient-to-b from-indigo-50 to-white dark:from-slate-800 dark:to-[#1A1F35] border-b border-indigo-50 dark:border-slate-800">
          <div className="flex items-start justify-between mb-4">
             <div onClick={() => handleNav('practice')} className="cursor-pointer">
                <Logo showText={false} className="w-8 h-8" />
             </div>
             {isMobile && (
               <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500">
                 <X size={20} />
               </button>
             )}
          </div>
          
          <div className="flex items-center gap-4">
             <div className="relative">
                <div className="w-14 h-14 rounded-full bg-white dark:bg-slate-700 p-1 shadow-sm border border-indigo-100 dark:border-slate-600">
                   <div className="w-full h-full rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-2xl">
                      {user.avatar}
                   </div>
                </div>
                <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-white p-1 rounded-full border-2 border-white dark:border-slate-800">
                   <Crown size={10} fill="currentColor" />
                </div>
             </div>
             <div className="flex-1 min-w-0">
                <h3 className="font-heading font-bold text-slate-900 dark:text-white truncate">{user.name}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{user.englishLevel}</p>
                <div className="mt-1.5 flex items-center gap-1.5">
                   <div className="h-1.5 flex-1 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full bg-primary-500 w-[60%] rounded-full"></div>
                   </div>
                   <span className="text-[10px] font-bold text-primary-600 dark:text-primary-400">Goal</span>
                </div>
             </div>
          </div>
        </div>

        {/* Scrollable Menu Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
           {menuGroups.map((group, idx) => (
             <div key={idx}>
               <h3 className="px-4 mb-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 opacity-80">
                 {group.title}
               </h3>
               <div className="space-y-0.5">
                 {group.items.map((item) => {
                   const isActive = activeTab === item.id;
                   return (
                     <button
                       key={item.id}
                       onClick={() => handleNav(item.id as AppTab)}
                       className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                         isActive 
                           ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 font-bold' 
                           : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 font-medium'
                       }`}
                     >
                       <div className={`relative z-10 ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-slate-400 group-hover:text-primary-500'} transition-colors`}>
                         {item.icon}
                       </div>
                       <span className="relative z-10 text-sm">{item.label}</span>
                       {isActive && (
                         <div className="absolute inset-y-0 left-0 w-1 bg-primary-500 rounded-full"></div>
                       )}
                     </button>
                   );
                 })}
               </div>
             </div>
           ))}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-indigo-50 dark:border-slate-800 bg-white dark:bg-[#1A1F35]">
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme}
              className="flex-1 flex items-center justify-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition text-sm font-bold text-slate-600 dark:text-slate-300"
            >
               {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
               <span>{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
            <button className="p-3 rounded-xl border border-red-100 dark:border-red-900/30 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition">
               <LogOut size={18} />
            </button>
          </div>
          <div className="mt-3 text-center text-[10px] text-slate-400">
             v1.0.0 • Made with ❤️ by Mahima Panday
          </div>
        </div>
      </div>
    </>
  );
};
