
import React from 'react';
import { Logo } from './Logo';
import { Mail, ChevronRight, HelpCircle, Shield, Info, Sparkles, Heart, CheckCircle2, AlertTriangle, FileText, Construction, Users, TrendingUp, MapPin } from 'lucide-react';

const LearningIllustration = () => (
  <svg viewBox="0 0 400 300" className="w-full h-auto max-w-md mx-auto opacity-90" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="girlGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#818CF8" />
        <stop offset="100%" stopColor="#C7D2FE" />
      </linearGradient>
      <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="5" />
        <feOffset dx="2" dy="4" result="offsetblur" />
        <feComponentTransfer>
          <feFuncA type="linear" slope="0.2" />
        </feComponentTransfer>
        <feMerge>
          <feMergeNode />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
    
    {/* Abstract Background Elements */}
    <circle cx="200" cy="150" r="120" fill="url(#girlGradient)" opacity="0.1" />
    <circle cx="280" cy="80" r="40" fill="#E0E7FF" opacity="0.4" />
    
    {/* Girl Silhouette */}
    <g filter="url(#softShadow)">
      {/* Hair */}
      <path d="M160,80 Q140,80 135,110 Q130,140 150,150 L160,160 L180,140 Q190,110 180,90 Q170,70 160,80" fill="#312E81" />
      
      {/* Face (Side profile, no features) */}
      <path d="M160,90 Q155,100 160,115 L160,125 L170,125 L170,100 Z" fill="#FFE4C4" />
      
      {/* Body / Shirt */}
      <path d="M150,150 Q130,170 130,220 L210,220 Q210,170 190,150 Z" fill="url(#girlGradient)" />
      
      {/* Arm holding book */}
      <path d="M180,160 Q200,180 220,170" stroke="#FFE4C4" strokeWidth="12" strokeLinecap="round" fill="none" />
      
      {/* Laptop/Book Base */}
      <path d="M180,190 L260,190 L240,220 L160,220 Z" fill="#4F46E5" opacity="0.8" />
      <path d="M180,190 L240,140 L260,190 Z" fill="#6366F1" opacity="0.6" />
    </g>
    
    {/* Floating Elements */}
    <path d="M250,100 L260,110 M260,100 L250,110" stroke="#F59E0B" strokeWidth="3" />
    <circle cx="100" cy="180" r="5" fill="#10B981" opacity="0.6" />
  </svg>
);

export const AboutPage: React.FC = () => (
  <div className="min-h-screen pb-12 animate-in fade-in slide-in-from-bottom-4">
    
    {/* 1. Premium Header Section */}
    <div className="relative bg-gradient-to-br from-indigo-600 via-primary-600 to-purple-600 text-white pt-12 pb-24 px-6 rounded-b-[3rem] shadow-xl text-center overflow-hidden">
      <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-x-20 -translate-y-20"></div>
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-orange-500/20 rounded-full blur-3xl translate-x-20 translate-y-20"></div>
      
      <div className="relative z-10 flex flex-col items-center gap-6">
        <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-md shadow-lg border border-white/20 hover:scale-105 transition-transform">
          <Logo className="w-32 h-12 text-white" showText={true} />
        </div>
        <div>
            <h1 className="text-4xl md:text-5xl font-heading font-bold mb-2 tracking-tight">About the Creator</h1>
            <div className="inline-flex items-center gap-2 bg-white/10 px-5 py-2 rounded-full backdrop-blur-sm border border-white/10 mt-2">
               <span className="text-indigo-100 font-medium text-sm">Made with Heart in India</span>
               <span className="text-xl leading-none">🇮🇳</span>
            </div>
        </div>
      </div>
    </div>

    <div className="max-w-5xl mx-auto px-6 -mt-16 relative z-20">
      <div className="grid md:grid-cols-2 gap-8 items-start">
        
        {/* Left Column: Story */}
        <div className="space-y-8">
            {/* Founder Card */}
            <div className="bg-surface-light dark:bg-surface-dark rounded-3xl p-8 shadow-xl border border-white dark:border-slate-800 text-center relative overflow-hidden group">
                <div className="w-24 h-24 mx-auto p-1 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-full shadow-lg mb-4">
                  <div className="w-full h-full rounded-full bg-indigo-50 dark:bg-slate-800 flex items-center justify-center overflow-hidden">
                     <Users size={40} className="text-indigo-300" />
                  </div>
                </div>
                <h2 className="text-2xl font-heading font-bold text-slate-900 dark:text-white">Hello, I’m Mahima Panday</h2>
                <p className="text-primary-500 font-bold uppercase tracking-widest text-[10px] mt-2 bg-primary-50 dark:bg-primary-900/20 px-3 py-1.5 rounded-full inline-block">Creator of Creater</p>
            </div>

            {/* Main Text */}
            <div className="bg-white/50 dark:bg-slate-900/50 p-6 rounded-3xl backdrop-blur-sm border border-white/50 dark:border-slate-800/50">
               <div className="prose dark:prose-invert max-w-none text-slate-600 dark:text-slate-300 leading-relaxed font-medium relative text-base md:text-lg">
                  <div className="space-y-6">
                    <p>
                      <span className="text-slate-900 dark:text-white font-bold">Creater</span> is created by <span className="text-slate-900 dark:text-white font-bold">Mahima Panday</span>, a learner and builder from India who believes that education should feel like a friend, not a fear.
                    </p>
                    <p>
                      This app is inspired by India’s rich diversity, warm culture, and the belief that learning grows stronger when we support each other. India is not just my country — it is my best friend, my teacher, and the reason I dream big. 
                    </p>
                    <p>
                      Through Creater, I want to help students, especially Indian learners, gain confidence in speaking, writing, and expressing themselves. Every feature is built with care, positivity, and a deep love for learning.
                    </p>
                  </div>
               </div>
               <div className="mt-8 text-center">
                  <p className="font-heading font-medium text-2xl text-slate-800 dark:text-slate-200 transform -rotate-2">~ Mahima Panday</p>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary-500 mt-1">Founder, Creater</p>
               </div>
            </div>
        </div>

        {/* Right Column: Illustration & Values */}
        <div className="space-y-8">
            {/* Illustration Card */}
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-soft border border-indigo-50 dark:border-slate-700 flex items-center justify-center min-h-[300px]">
               <LearningIllustration />
            </div>

            {/* Values Section */}
            <div className="bg-[#EEF2FF] dark:bg-[#151928] rounded-[2rem] p-8 border border-indigo-100 dark:border-slate-800 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-5"><Sparkles size={100} /></div>
                <h3 className="text-center font-heading font-bold text-lg text-slate-800 dark:text-white mb-6 bg-white dark:bg-slate-800/50 inline-block px-6 py-2 rounded-full mx-auto shadow-sm">Our Values</h3>
                <div className="grid gap-4 relative z-10">
                  <ValueItem 
                    icon={<Heart className="fill-pink-400 text-pink-500" size={18} />} 
                    title="Positivity & Encouragement" 
                    desc="Every effort matters." 
                  />
                  <ValueItem 
                    icon={<Shield className="fill-teal-400 text-teal-600" size={18} />} 
                    title="Judgement-Free Zone" 
                    desc="A safe place to learn." 
                  />
                  <ValueItem 
                    icon={<Users className="fill-purple-400 text-purple-500" size={18} />} 
                    title="Inclusiveness & Respect" 
                    desc="Honoring every learner." 
                  />
                  <ValueItem 
                    icon={<TrendingUp className="fill-blue-400 text-blue-500" size={18} />} 
                    title="Growth Mindset" 
                    desc="Learning is a journey." 
                  />
                </div>
            </div>

            {/* India Tribute */}
            <div className="relative bg-gradient-to-r from-orange-50 to-purple-50 dark:from-orange-900/10 dark:to-purple-900/10 rounded-[2rem] p-6 text-center overflow-hidden border border-orange-100 dark:border-orange-900/20 group">
                <div className="relative z-10 flex flex-col items-center gap-3">
                    <h3 className="text-lg font-heading font-bold text-slate-800 dark:text-white">Made With Love in India</h3>
                    {/* Tricolor Indicator */}
                    <div className="flex justify-center gap-2 h-1.5 w-24 rounded-full overflow-hidden">
                      <span className="flex-1 bg-[#FF9933]"></span>
                      <span className="flex-1 bg-white"></span>
                      <span className="flex-1 bg-[#138808]"></span>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* Footer Tagline */}
      <div className="border-t border-slate-100 dark:border-slate-800 mt-12 pt-8 text-center pb-8">
          <p className="text-xs text-slate-400 font-medium tracking-wide">Creater — Created with ❤️ in India by Mahima Panday</p>
      </div>
    </div>
  </div>
);

const ValueItem: React.FC<{icon: React.ReactNode, title: string, desc: string}> = ({icon, title, desc}) => (
  <div className="flex items-center gap-4 p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm hover:shadow-md transition-all hover:translate-x-1">
     <div className="bg-slate-50 dark:bg-slate-700 p-2.5 rounded-xl shrink-0">
       {icon}
     </div>
     <div>
       <h4 className="font-bold text-slate-800 dark:text-white text-sm leading-tight mb-0.5">{title}</h4>
       <p className="text-xs text-slate-500 dark:text-slate-400 italic">"{desc}"</p>
     </div>
  </div>
);

export const FAQPage: React.FC = () => {
  const faqs = [
    { q: "Is Creater free to use?", a: "Yes! The core features are free for all students." },
    { q: "How is my pronunciation score calculated?", a: "We use an advanced AI engine that compares your speech patterns to native English speakers, focusing on clarity, intonation, and stress." },
    { q: "Can I use this app offline?", a: "Currently, you need an active internet connection for the AI analysis features." },
    { q: "What if I don't understand the English feedback?", a: "You can toggle the 'Hindi Explanation' option in the settings or on the analysis card." },
    { q: "Is my voice data saved?", a: "We process audio in real-time. We do not store your voice recordings on our servers permanently." },
    { q: "How can I improve my fluency score?", a: "Try to speak in full sentences, reduce 'uh' and 'um' fillers, and practice the Daily Speaking tasks." },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in">
       <div className="text-center mb-8">
         <div className="inline-flex items-center justify-center p-3 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl mb-4">
           <HelpCircle size={32} />
         </div>
         <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white">Frequently Asked Questions</h1>
         <p className="text-slate-500 mt-2">Find answers to common questions about your learning journey.</p>
       </div>

       <div className="grid gap-4">
         {faqs.map((faq, i) => (
           <div key={i} className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-sm border border-white dark:border-slate-800">
             <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-2">{faq.q}</h3>
             <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{faq.a}</p>
           </div>
         ))}
       </div>
    </div>
  );
};

export const HelpPage: React.FC = () => (
  <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in">
    <div className="bg-primary-600 text-white rounded-3xl p-8 shadow-glow text-center">
       <h1 className="text-3xl font-heading font-bold mb-2">How can we help?</h1>
       <p className="opacity-90">We are here to support your learning experience.</p>
    </div>

    <div className="grid gap-4 md:grid-cols-2">
      <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800">
         <h3 className="font-bold text-lg mb-2">Technical Support</h3>
         <p className="text-slate-600 dark:text-slate-400 text-sm mb-4">Having trouble with the microphone or app loading?</p>
         <button className="text-primary-600 font-bold text-sm flex items-center gap-1">Troubleshoot <ChevronRight size={16}/></button>
      </div>
      <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl shadow-soft border border-white dark:border-slate-800">
         <h3 className="font-bold text-lg mb-2">Account Issues</h3>
         <p className="text-slate-600 dark:text-slate-400 text-sm mb-4">Need to reset your progress or change settings?</p>
         <button className="text-primary-600 font-bold text-sm flex items-center gap-1">Manage Account <ChevronRight size={16}/></button>
      </div>
    </div>
  </div>
);

export const PrivacyPage: React.FC = () => (
  <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in">
    <div className="flex items-center gap-3 mb-6">
       <Shield className="text-primary-500" size={32} />
       <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white">Privacy & Terms</h1>
    </div>
    
    <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 space-y-6 text-slate-600 dark:text-slate-400 leading-relaxed">
       <p>Last updated: October 2025</p>
       
       <h3 className="text-lg font-bold text-slate-800 dark:text-white">1. Data Protection</h3>
       <p>We take your privacy seriously. Your voice data is processed for analysis and is not permanently stored. We do not sell your data to third parties.</p>
       
       <h3 className="text-lg font-bold text-slate-800 dark:text-white">2. Usage Terms</h3>
       <p>Creater is an educational tool. By using the app, you agree to treat the community with respect and use the content for personal learning only.</p>
       
       <h3 className="text-lg font-bold text-slate-800 dark:text-white">3. Content Safety</h3>
       <p>Our AI is designed with a safety layer to ensure all interactions are positive, non-judgmental, and safe for all ages.</p>
    </div>
  </div>
);

export const AppInfoPage: React.FC = () => (
  <div className="max-w-md mx-auto text-center space-y-6 py-10 animate-in fade-in">
     <div className="w-24 h-24 mx-auto bg-gradient-to-tr from-primary-100 to-purple-100 rounded-3xl flex items-center justify-center text-primary-600 shadow-sm">
        <Info size={40} />
     </div>
     <div>
       <h1 className="text-2xl font-heading font-bold text-slate-800 dark:text-white">Creater</h1>
       <p className="text-slate-500 font-mono text-sm mt-1">Version 1.0.0</p>
     </div>
     
     <div className="bg-surface-light dark:bg-surface-dark p-6 rounded-2xl border border-white dark:border-slate-800">
        <p className="text-slate-600 dark:text-slate-400 text-sm mb-4">
          Built with React, Tailwind, and Gemini AI.
        </p>
        <p className="text-primary-600 font-bold text-sm flex items-center justify-center gap-2">
           <Heart size={14} className="fill-current" /> Made for Learners
        </p>
     </div>
     
     <div className="text-xs text-slate-400">
       © 2025 Mahima Panday. All rights reserved.
     </div>
  </div>
);

export const SafetyCenterPage: React.FC = () => (
  <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in">
    <div className="flex items-center gap-3 mb-6">
       <Shield className="text-teal-500" size={32} />
       <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white">Safety Center</h1>
    </div>
    <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 space-y-4">
      <div className="flex items-start gap-4 p-4 bg-teal-50 dark:bg-teal-900/20 rounded-xl">
         <CheckCircle2 className="text-teal-600 shrink-0" />
         <div>
            <h3 className="font-bold text-teal-800 dark:text-teal-300">Positive Learning Zone</h3>
            <p className="text-sm text-teal-700 dark:text-teal-400 mt-1">We enforce a strict non-judgmental policy. Mistakes are celebrated as opportunities to learn.</p>
         </div>
      </div>
      <div className="flex items-start gap-4 p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl">
         <Heart className="text-indigo-600 shrink-0" />
         <div>
            <h3 className="font-bold text-indigo-800 dark:text-indigo-300">Emotional Support</h3>
            <p className="text-sm text-indigo-700 dark:text-indigo-400 mt-1">Our AI is trained to be kind, encouraging, and supportive at all times.</p>
         </div>
      </div>
    </div>
  </div>
);

export const GuidelinesPage: React.FC = () => (
  <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in">
     <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-6">Community Guidelines</h1>
     <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 space-y-4 text-slate-600 dark:text-slate-400">
        <ul className="list-disc pl-5 space-y-2">
           <li>Be respectful to others (even AI).</li>
           <li>Do not use offensive language during voice practice.</li>
           <li>Support fellow learners if we add community features.</li>
           <li>Keep your profile information appropriate.</li>
        </ul>
     </div>
  </div>
);

export const ReportPage: React.FC = () => (
  <div className="max-w-xl mx-auto space-y-6 animate-in fade-in">
     <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-6">Report an Issue</h1>
     <div className="bg-surface-light dark:bg-surface-dark p-8 rounded-3xl shadow-soft border border-white dark:border-slate-800 text-center">
        <AlertTriangle size={48} className="mx-auto text-amber-500 mb-4" />
        <p className="text-slate-600 dark:text-slate-400 mb-6">Found a bug or encountered inappropriate content? Please let us know.</p>
        <button className="px-6 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-full font-bold">Open Report Form</button>
     </div>
  </div>
);

export const ComingSoon: React.FC<{title: string}> = ({title}) => (
   <div className="flex flex-col items-center justify-center min-h-[50vh] text-center px-4 animate-in fade-in">
      <div className="p-6 bg-slate-100 dark:bg-slate-800 rounded-full mb-6">
         <Construction size={48} className="text-slate-400" />
      </div>
      <h1 className="text-3xl font-heading font-bold text-slate-800 dark:text-white mb-2">{title}</h1>
      <p className="text-slate-500 max-w-md mx-auto">This feature is currently under development. Stay tuned for updates in the next version!</p>
      <button className="mt-8 px-6 py-3 border border-slate-200 dark:border-slate-700 rounded-full font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
         Notify Me When Ready
      </button>
   </div>
);
