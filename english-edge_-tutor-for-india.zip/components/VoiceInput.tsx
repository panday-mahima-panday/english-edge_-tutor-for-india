
import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Loader2 } from 'lucide-react';

interface VoiceInputProps {
  onAudioCaptured: (base64: string, mimeType: string) => void;
  className?: string;
  buttonClass?: string;
  iconSize?: number;
}

export const VoiceInput: React.FC<VoiceInputProps> = ({ onAudioCaptured, className = "", buttonClass = "", iconSize = 20 }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [duration, setDuration] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = handleAudioStop;
      mediaRecorder.start();
      setIsRecording(true);
      setDuration(0);
      timerRef.current = window.setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);

    } catch (err) {
      console.error("Mic error:", err);
      alert("Could not access microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleAudioStop = async () => {
    setIsProcessing(true);
    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
    
    const reader = new FileReader();
    reader.readAsDataURL(audioBlob);
    reader.onloadend = async () => {
      const base64String = (reader.result as string).split(',')[1];
      onAudioCaptured(base64String, audioBlob.type);
      setIsProcessing(false);
    };
  };

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`relative ${className}`}>
      {/* Floating Timer Badge */}
      {isRecording && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full whitespace-nowrap shadow-md animate-in fade-in slide-in-from-bottom-2">
          {formatTime(duration)}
        </div>
      )}
      
      <button
        onClick={toggleRecording}
        disabled={isProcessing}
        className={`rounded-full transition-all duration-300 flex items-center justify-center ${buttonClass} ${
          isRecording 
            ? 'bg-red-500 text-white animate-pulse ring-4 ring-red-200 dark:ring-red-900' 
            : 'bg-indigo-100 dark:bg-slate-700 text-indigo-600 dark:text-slate-300 hover:bg-indigo-200 dark:hover:bg-slate-600'
        }`}
        title="Record Audio"
        style={{ width: iconSize * 2.5, height: iconSize * 2.5 }}
      >
        {isProcessing ? (
          <Loader2 size={iconSize} className="animate-spin" />
        ) : isRecording ? (
          <Square size={iconSize} fill="currentColor" />
        ) : (
          <Mic size={iconSize} />
        )}
      </button>
      
      {isRecording && (
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
        </span>
      )}
    </div>
  );
};
