
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult, DailyPracticeContent, BridgeTranslation, BridgeEvaluation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- Safety & Tone Configuration ---
const SAFETY_LAYER = `
POSITIVE LEARNING SAFETY LAYER ACTIVE:
1. Use ONLY supportive, non-judgmental language.
2. NEVER use words like 'wrong', 'incorrect', 'bad', 'fail', 'mistake', 'poor'.
3. Frame every correction as an improvement opportunity (e.g., "Great attempt, here is a smoother version", "You are improving, let's try this sound").
4. Be culturally sensitive, inclusive, and respectful.
5. Always end with specific encouragement (e.g., "You can do it", "Proud of your effort").
6. Treat the user as a valued student who is growing every day.
`;

// --- Schemas ---

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    transcript: { type: Type.STRING, description: "The transcription of what the student said." },
    score: { type: Type.NUMBER, description: "Overall score out of 10." },
    cefrLevel: { type: Type.STRING, description: "Estimated CEFR Level (A1, A2, B1, B2, C1, C2)." },
    
    // Grammar Engine
    grammarCorrection: { type: Type.STRING, description: "Corrected version of the sentence." },
    detailedGrammarErrors: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          errorType: { type: Type.STRING },
          correction: { type: Type.STRING },
          reason: { type: Type.STRING },
          example: { type: Type.STRING }
        },
        required: ["errorType", "correction", "reason", "example"]
      }
    },

    // Vocabulary Engine
    betterVocabulary: { type: Type.STRING, description: "Suggestion for better words." },
    vocabularyAnalysis: {
      type: Type.OBJECT,
      properties: {
        cefrLevel: { type: Type.STRING, description: "Vocabulary level detected." },
        betterWords: { type: Type.ARRAY, items: { type: Type.STRING } },
        varietyScore: { type: Type.NUMBER, description: "Score 0-10 for lexical variety." }
      },
      required: ["cefrLevel", "betterWords", "varietyScore"]
    },

    // Fluency Engine
    fluencyFeedback: { type: Type.STRING, description: "Text feedback on flow and speed." },
    fluencyMetrics: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        wpm: { type: Type.NUMBER, description: "Estimated words per minute." },
        fillersCount: { type: Type.NUMBER, description: "Count of uh, um, like." },
        pausePatterns: { type: Type.STRING, description: "Description of pausing (e.g. Natural, Choppy)." }
      },
      required: ["score", "wpm", "fillersCount", "pausePatterns"]
    },

    // General & Pronunciation
    hindiExplanation: { type: Type.STRING },
    encouragement: { type: Type.STRING },
    pronunciation: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        intonationPattern: { type: Type.STRING, description: "e.g. Flat, Rising, Expressive" },
        mispronouncedWords: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              word: { type: Type.STRING },
              ipa: { type: Type.STRING },
              correctiveTip: { type: Type.STRING },
              hindiTip: { type: Type.STRING },
              mouthPosition: { type: Type.STRING, description: "Physical instruction e.g. 'Round your lips', 'Tongue tip behind teeth'." },
              syllables: { type: Type.STRING, description: "Syllable breakdown e.g. 'com-pu-ter'." },
              stressPattern: { type: Type.STRING, description: "Explanation of where to place stress." }
            },
            required: ["word", "ipa", "correctiveTip"]
          }
        },
        feedback: { type: Type.STRING }
      },
      required: ["score", "mispronouncedWords", "feedback"]
    },

    // Motivation & Insights
    strengths: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List 1-3 things the user did well (e.g. 'Clear R sound', 'Good confidence')." 
    },
    learningInsights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING },
          observation: { type: Type.STRING, description: "Gentle non-judgmental observation." },
          softCorrection: { type: Type.STRING, description: "Supportive suggestion." },
          encouragement: { type: Type.STRING, description: "Motivational closing." }
        },
        required: ["type", "observation", "softCorrection", "encouragement"]
      },
      description: "Convert errors into gentle learning moments."
    }
  },
  required: ["score", "grammarCorrection", "betterVocabulary", "fluencyFeedback", "hindiExplanation", "encouragement", "strengths", "learningInsights"],
};

const dailyContentSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    motivationalMessage: { type: Type.STRING },
    vocabulary: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          word: { type: Type.STRING },
          meaning: { type: Type.STRING },
          example: { type: Type.STRING },
          pronunciationGuide: { type: Type.STRING },
          level: { type: Type.STRING, description: "CEFR Level e.g. B1, C2" },
          synonyms: { type: Type.ARRAY, items: { type: Type.STRING } },
          hindiMeaning: { type: Type.STRING },
          extraExamples: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["word", "meaning", "example", "pronunciationGuide", "level", "synonyms", "extraExamples"],
      },
    },
    speakingTask: { type: Type.STRING },
    grammarTip: { type: Type.STRING },
    grammarChallenge: {
      type: Type.OBJECT,
      properties: {
        question: { type: Type.STRING },
        options: { type: Type.ARRAY, items: { type: Type.STRING } },
        correctAnswer: { type: Type.INTEGER },
        explanation: { type: Type.STRING }
      },
      required: ["question", "options", "correctAnswer", "explanation"]
    },
    vocabQuiz: {
      type: Type.OBJECT,
      properties: {
        question: { type: Type.STRING },
        options: { type: Type.ARRAY, items: { type: Type.STRING } },
        correctAnswer: { type: Type.INTEGER },
        explanation: { type: Type.STRING }
      },
      required: ["question", "options", "correctAnswer", "explanation"]
    }
  },
  required: ["motivationalMessage", "vocabulary", "speakingTask", "grammarTip", "grammarChallenge", "vocabQuiz"],
};

const translationSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    originalText: { type: Type.STRING },
    translatedText: { type: Type.STRING },
    explanation: { type: Type.STRING },
    grammarNotes: { type: Type.STRING },
    hindiExplanation: { type: Type.STRING }
  },
  required: ["translatedText", "explanation", "grammarNotes"]
};

const bridgeEvaluationSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    transcribedText: { type: Type.STRING },
    pronunciationScore: { type: Type.NUMBER },
    fluencyScore: { type: Type.NUMBER },
    mispronouncedWords: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          word: { type: Type.STRING },
          ipa: { type: Type.STRING },
          correctiveTip: { type: Type.STRING },
          hindiTip: { type: Type.STRING }
        },
        required: ["word", "ipa", "correctiveTip"]
      }
    },
    feedback: { type: Type.STRING }
  },
  required: ["transcribedText", "pronunciationScore", "fluencyScore", "mispronouncedWords", "feedback"]
};

const model = "gemini-2.5-flash";

// --- API Functions ---

export const analyzeSentence = async (text: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Analyze this English sentence spoken by an Indian college student: "${text}". Run all engines (Grammar, Vocab, Fluency, Motivation). Estimate CEFR level.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: `You are an advanced English Mastery AI. 
        1. Grammar Engine: Detect errors. 
        2. Vocabulary Engine: Suggest C1/C2 alternatives. 
        3. Fluency Engine: Analyze sentence flow. 
        4. Motivation Engine: Identify STRENGTHS and generate gentle LEARNING INSIGHTS instead of harsh errors.
        ${SAFETY_LAYER}`,
      },
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as AnalysisResult;
  } catch (error) {
    console.error("Error analyzing sentence:", error);
    throw error;
  }
};

export const analyzeAudio = async (base64Audio: string, mimeType: string, context?: string): Promise<AnalysisResult> => {
  try {
    const promptText = context 
      ? `Analyze this audio response to the prompt: "${context}". 1. Transcribe. 2. Pronunciation. 3. Fluency. 4. Motivation.`
      : "Analyze this audio from an Indian student. 1. Transcribe. 2. Pronunciation: Check stress, intonation. 3. Fluency: WPM, fillers. 4. Motivation: Highlight Strengths. 5. Insights: Gentle guidance.";

    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: mimeType, data: base64Audio } },
          { text: promptText }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: `You are an expert Linguistic AI Engine with a kind personality. 
        Evaluate spoken English with strict native standards but DELIVER feedback with extreme kindness. 
        ${SAFETY_LAYER} 
        Provide specific 'learningInsights' that explain the 'why' and 'how' gently.
        
        For Pronunciation:
        - Focus on common Indian learner challenges (V/W sound confusion, S/SH sound, Retroflex T/D, Rolling R).
        - Populate 'mouthPosition' with specific physical instructions (e.g. 'Bite lower lip for V', 'Tongue tip behind top teeth for T').
        - Provide 'syllables' breakdown and 'stressPattern' advice.
        - Provide Hindi tips where relevant to explain the sound difference.`,
      },
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as AnalysisResult;
  } catch (error) {
    console.error("Error analyzing audio:", error);
    throw error;
  }
};

export const getDailyPractice = async (): Promise<DailyPracticeContent> => {
  try {
    const response = await ai.models.generateContent({
      model,
      contents: "Generate daily English practice content for an Indian college student. Context: Campus, Internship, Job Interview, Technology.",
      config: {
        responseMimeType: "application/json",
        responseSchema: dailyContentSchema,
        systemInstruction: `Generate high-quality English learning content. Vocabulary should range from B1 to C1 levels. 
        Provide rich vocabulary details including synonyms and multiple examples.
        Speaking task should be a realistic scenario. ${SAFETY_LAYER}`,
      },
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as DailyPracticeContent;
  } catch (error) {
    console.error("Error generating daily content:", error);
    throw error;
  }
};

export const createChatSession = () => {
  return ai.chats.create({
    model,
    config: {
      systemInstruction: `You are a professional yet friendly English Communication Coach. Roleplay scenarios like Job Interviews, Visa Interviews, Hostel Debates, or Exam Viva. Correct mistakes naturally. Keep the conversation flowing. ${SAFETY_LAYER}`,
    },
  });
};

export const translateToEnglish = async (text: string): Promise<BridgeTranslation> => {
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Translate to natural English: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: translationSchema,
        systemInstruction: `Convert Indian language logic to Native English logic. Explain the structural changes clearly. ${SAFETY_LAYER}`,
      }
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as BridgeTranslation;
  } catch (error) {
    console.error("Error translating text:", error);
    throw error;
  }
};

export const evaluateBridgeAudio = async (base64Audio: string, mimeType: string, targetText: string): Promise<BridgeEvaluation> => {
  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: mimeType, data: base64Audio } },
          { text: `Target: "${targetText}". Evaluate accuracy.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: bridgeEvaluationSchema,
        systemInstruction: `Compare user audio to target sentence. ${SAFETY_LAYER}`,
      }
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as BridgeEvaluation;
  } catch (error) {
    console.error("Error evaluating bridge audio:", error);
    throw error;
  }
};
